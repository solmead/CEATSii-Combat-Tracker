<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DisplayPreBuitChars
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.CharName = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.BaseLevel = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.BaseInititive = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.HitPoints = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.ExhaustionPoints = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.PowerPoints = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.IsPC = New System.Windows.Forms.RadioButton
        Me.IsNPC = New System.Windows.Forms.RadioButton
        Me.ListBox1 = New System.Windows.Forms.ListBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Descrip = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.DB = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.MM = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.AT = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.AddArmor = New System.Windows.Forms.Button
        Me.RemoveArmor = New System.Windows.Forms.Button
        Me.RemoveWeapon = New System.Windows.Forms.Button
        Me.AddWeapon = New System.Windows.Forms.Button
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.WeaponWeight = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.WeaponBonus = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.WeaponName = New System.Windows.Forms.TextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.ListBox2 = New System.Windows.Forms.ListBox
        Me.WeaponIs2H = New System.Windows.Forms.CheckBox
        Me.OB = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Strength = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'CharName
        '
        Me.CharName.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CharName.Location = New System.Drawing.Point(57, 7)
        Me.CharName.Name = "CharName"
        Me.CharName.Size = New System.Drawing.Size(495, 26)
        Me.CharName.TabIndex = 4
        Me.CharName.Text = "Deekin Merryweather"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 10)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Name:"
        '
        'BaseLevel
        '
        Me.BaseLevel.Location = New System.Drawing.Point(105, 36)
        Me.BaseLevel.Name = "BaseLevel"
        Me.BaseLevel.Size = New System.Drawing.Size(31, 20)
        Me.BaseLevel.TabIndex = 6
        Me.BaseLevel.Text = "50"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(63, 39)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(36, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Level:"
        '
        'BaseInititive
        '
        Me.BaseInititive.Location = New System.Drawing.Point(105, 59)
        Me.BaseInititive.Name = "BaseInititive"
        Me.BaseInititive.Size = New System.Drawing.Size(31, 20)
        Me.BaseInititive.TabIndex = 8
        Me.BaseInititive.Text = "50"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(29, 62)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(70, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Base Inititive:"
        '
        'HitPoints
        '
        Me.HitPoints.Location = New System.Drawing.Point(105, 85)
        Me.HitPoints.Name = "HitPoints"
        Me.HitPoints.Size = New System.Drawing.Size(31, 20)
        Me.HitPoints.TabIndex = 10
        Me.HitPoints.Text = "50"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(44, 88)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(55, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Hit Points:"
        '
        'ExhaustionPoints
        '
        Me.ExhaustionPoints.Location = New System.Drawing.Point(105, 111)
        Me.ExhaustionPoints.Name = "ExhaustionPoints"
        Me.ExhaustionPoints.Size = New System.Drawing.Size(31, 20)
        Me.ExhaustionPoints.TabIndex = 12
        Me.ExhaustionPoints.Text = "500"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(5, 114)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(94, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Exhaustion Points:"
        '
        'PowerPoints
        '
        Me.PowerPoints.Location = New System.Drawing.Point(105, 137)
        Me.PowerPoints.Name = "PowerPoints"
        Me.PowerPoints.Size = New System.Drawing.Size(31, 20)
        Me.PowerPoints.TabIndex = 14
        Me.PowerPoints.Text = "50"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(27, 140)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(72, 13)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Power Points:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.IsPC)
        Me.GroupBox1.Controls.Add(Me.IsNPC)
        Me.GroupBox1.Location = New System.Drawing.Point(142, 39)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(70, 73)
        Me.GroupBox1.TabIndex = 15
        Me.GroupBox1.TabStop = False
        '
        'IsPC
        '
        Me.IsPC.AutoSize = True
        Me.IsPC.Location = New System.Drawing.Point(6, 42)
        Me.IsPC.Name = "IsPC"
        Me.IsPC.Size = New System.Drawing.Size(50, 17)
        Me.IsPC.TabIndex = 1
        Me.IsPC.TabStop = True
        Me.IsPC.Text = "Is PC"
        Me.IsPC.UseVisualStyleBackColor = True
        '
        'IsNPC
        '
        Me.IsNPC.AutoSize = True
        Me.IsNPC.Location = New System.Drawing.Point(6, 19)
        Me.IsNPC.Name = "IsNPC"
        Me.IsNPC.Size = New System.Drawing.Size(58, 17)
        Me.IsNPC.TabIndex = 0
        Me.IsNPC.TabStop = True
        Me.IsNPC.Text = "Is NPC"
        Me.IsNPC.UseVisualStyleBackColor = True
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(261, 183)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(84, 82)
        Me.ListBox1.TabIndex = 16
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Descrip)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.DB)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.MM)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.AT)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Location = New System.Drawing.Point(352, 183)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(200, 138)
        Me.GroupBox2.TabIndex = 17
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Armor"
        Me.GroupBox2.Visible = False
        '
        'Descrip
        '
        Me.Descrip.Location = New System.Drawing.Point(73, 97)
        Me.Descrip.Multiline = True
        Me.Descrip.Name = "Descrip"
        Me.Descrip.Size = New System.Drawing.Size(121, 35)
        Me.Descrip.TabIndex = 22
        Me.Descrip.Text = "50"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(4, 100)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(63, 13)
        Me.Label10.TabIndex = 21
        Me.Label10.Text = "Description:"
        '
        'DB
        '
        Me.DB.Location = New System.Drawing.Point(106, 71)
        Me.DB.Name = "DB"
        Me.DB.Size = New System.Drawing.Size(31, 20)
        Me.DB.TabIndex = 20
        Me.DB.Text = "50"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(75, 74)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(25, 13)
        Me.Label9.TabIndex = 19
        Me.Label9.Text = "DB:"
        '
        'MM
        '
        Me.MM.Location = New System.Drawing.Point(106, 45)
        Me.MM.Name = "MM"
        Me.MM.Size = New System.Drawing.Size(31, 20)
        Me.MM.TabIndex = 18
        Me.MM.Text = "50"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(4, 48)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(96, 13)
        Me.Label7.TabIndex = 17
        Me.Label7.Text = "Moving Maneuver:"
        '
        'AT
        '
        Me.AT.Location = New System.Drawing.Point(76, 19)
        Me.AT.Name = "AT"
        Me.AT.Size = New System.Drawing.Size(31, 20)
        Me.AT.TabIndex = 16
        Me.AT.Text = "500"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 22)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(64, 13)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "Armor Type:"
        '
        'AddArmor
        '
        Me.AddArmor.Location = New System.Drawing.Point(261, 271)
        Me.AddArmor.Name = "AddArmor"
        Me.AddArmor.Size = New System.Drawing.Size(82, 22)
        Me.AddArmor.TabIndex = 18
        Me.AddArmor.Text = "Add"
        Me.AddArmor.UseVisualStyleBackColor = True
        '
        'RemoveArmor
        '
        Me.RemoveArmor.Location = New System.Drawing.Point(261, 299)
        Me.RemoveArmor.Name = "RemoveArmor"
        Me.RemoveArmor.Size = New System.Drawing.Size(82, 22)
        Me.RemoveArmor.TabIndex = 19
        Me.RemoveArmor.Text = "Remove"
        Me.RemoveArmor.UseVisualStyleBackColor = True
        '
        'RemoveWeapon
        '
        Me.RemoveWeapon.Location = New System.Drawing.Point(261, 155)
        Me.RemoveWeapon.Name = "RemoveWeapon"
        Me.RemoveWeapon.Size = New System.Drawing.Size(82, 22)
        Me.RemoveWeapon.TabIndex = 23
        Me.RemoveWeapon.Text = "Remove"
        Me.RemoveWeapon.UseVisualStyleBackColor = True
        '
        'AddWeapon
        '
        Me.AddWeapon.Location = New System.Drawing.Point(261, 127)
        Me.AddWeapon.Name = "AddWeapon"
        Me.AddWeapon.Size = New System.Drawing.Size(82, 22)
        Me.AddWeapon.TabIndex = 22
        Me.AddWeapon.Text = "Add"
        Me.AddWeapon.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.OB)
        Me.GroupBox3.Controls.Add(Me.Label11)
        Me.GroupBox3.Controls.Add(Me.WeaponIs2H)
        Me.GroupBox3.Controls.Add(Me.WeaponWeight)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Controls.Add(Me.WeaponBonus)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.WeaponName)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Location = New System.Drawing.Point(352, 39)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(200, 138)
        Me.GroupBox3.TabIndex = 21
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Weapon"
        Me.GroupBox3.Visible = False
        '
        'WeaponWeight
        '
        Me.WeaponWeight.Location = New System.Drawing.Point(50, 71)
        Me.WeaponWeight.Name = "WeaponWeight"
        Me.WeaponWeight.Size = New System.Drawing.Size(31, 20)
        Me.WeaponWeight.TabIndex = 20
        Me.WeaponWeight.Text = "50"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(6, 75)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(44, 13)
        Me.Label12.TabIndex = 19
        Me.Label12.Text = "Weight:"
        '
        'WeaponBonus
        '
        Me.WeaponBonus.Location = New System.Drawing.Point(50, 45)
        Me.WeaponBonus.Name = "WeaponBonus"
        Me.WeaponBonus.Size = New System.Drawing.Size(31, 20)
        Me.WeaponBonus.TabIndex = 18
        Me.WeaponBonus.Text = "50"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(4, 48)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(40, 13)
        Me.Label13.TabIndex = 17
        Me.Label13.Text = "Bonus:"
        '
        'WeaponName
        '
        Me.WeaponName.Location = New System.Drawing.Point(94, 19)
        Me.WeaponName.Name = "WeaponName"
        Me.WeaponName.Size = New System.Drawing.Size(100, 20)
        Me.WeaponName.TabIndex = 16
        Me.WeaponName.Text = "500"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(6, 22)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(82, 13)
        Me.Label14.TabIndex = 15
        Me.Label14.Text = "Weapon Name:"
        '
        'ListBox2
        '
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.Location = New System.Drawing.Point(261, 39)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(84, 82)
        Me.ListBox2.TabIndex = 20
        '
        'WeaponIs2H
        '
        Me.WeaponIs2H.AutoSize = True
        Me.WeaponIs2H.Location = New System.Drawing.Point(9, 97)
        Me.WeaponIs2H.Name = "WeaponIs2H"
        Me.WeaponIs2H.Size = New System.Drawing.Size(84, 17)
        Me.WeaponIs2H.TabIndex = 21
        Me.WeaponIs2H.Text = "Is 2 Handed"
        Me.WeaponIs2H.UseVisualStyleBackColor = True
        '
        'OB
        '
        Me.OB.Location = New System.Drawing.Point(141, 46)
        Me.OB.Name = "OB"
        Me.OB.Size = New System.Drawing.Size(31, 20)
        Me.OB.TabIndex = 23
        Me.OB.Text = "50"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(95, 49)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(25, 13)
        Me.Label11.TabIndex = 22
        Me.Label11.Text = "OB:"
        '
        'Strength
        '
        Me.Strength.Location = New System.Drawing.Point(105, 161)
        Me.Strength.Name = "Strength"
        Me.Strength.Size = New System.Drawing.Size(31, 20)
        Me.Strength.TabIndex = 25
        Me.Strength.Text = "50"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(27, 164)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(83, 13)
        Me.Label15.TabIndex = 24
        Me.Label15.Text = "Strength Bonus:"
        '
        'DisplayPreBuitChars
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.Strength)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.RemoveWeapon)
        Me.Controls.Add(Me.AddWeapon)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.ListBox2)
        Me.Controls.Add(Me.RemoveArmor)
        Me.Controls.Add(Me.AddArmor)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PowerPoints)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.ExhaustionPoints)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.HitPoints)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.BaseInititive)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.BaseLevel)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CharName)
        Me.Controls.Add(Me.Label2)
        Me.Name = "DisplayPreBuitChars"
        Me.Size = New System.Drawing.Size(568, 338)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents CharName As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents BaseLevel As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents BaseInititive As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents HitPoints As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ExhaustionPoints As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents PowerPoints As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents IsPC As System.Windows.Forms.RadioButton
    Friend WithEvents IsNPC As System.Windows.Forms.RadioButton
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents MM As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents AT As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents AddArmor As System.Windows.Forms.Button
    Friend WithEvents RemoveArmor As System.Windows.Forms.Button
    Friend WithEvents Descrip As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents DB As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents RemoveWeapon As System.Windows.Forms.Button
    Friend WithEvents AddWeapon As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents WeaponWeight As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents WeaponBonus As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents WeaponName As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
    Friend WithEvents WeaponIs2H As System.Windows.Forms.CheckBox
    Friend WithEvents OB As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Strength As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label

End Class
