Public Class MainForm
    Dim DB As New RMSSDataDataContext
    Dim GI As New GameInstance
    Private selectedCData As DisplayCharacterData
    Private CurAct As Action
    Private Started As Boolean = False
    Private Sub CreatureEditingToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreatureEditingToolStripMenuItem.Click
        Dim F As New EditCreature(DB, GI)
        F.ShowDialog()
        F.Dispose()
        F = Nothing
        Call displayChars()
        Call DisplayActions()
        'If Not Started Then
        MoveNext()
        'S'tarted = True
        'End If
    End Sub

    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'Dim FI As New System.IO.FileInfo(My.Application.Info.DirectoryPath & "\datafile.ser")
        'If FI.Exists Then
        ' MD = Handler.LoadFromFile(FI)
        'End If
        'MD.Check()
        'MD.CreatureList = Creature.GetCreatures
        'MD.PreBuiltCharsList = PreBuiltChar.GetPreBuiltChars
        'MD.ArmorList = Armor.GetArmors
        'MD.WeaponList = Weapon.GetWeapons
        GI.Actions.Clear()
        GI.Chars.Clear()

        Call displayChars()
        Call DisplayActions()
        For Each GA In DB.ActionGroups
            ListBox2.Items.Add(GA)
        Next
    End Sub
    Private Sub DisplayActions()
        Dim CD As DisplayCharacterData = Nothing
        Dim TLst As New ArrayList
        Dim Found As Boolean = False
        For Each CD In CharacterDisplay.Controls
            Dim Actn As Action
            Found = False
            For Each Actn In GI.Actions
                If Actn Is CD.WhoAmI Then
                    Found = True
                    Exit For
                End If
            Next
            If Not Found Then
                TLst.Add(CD)
            End If
        Next
        For Each CD In TLst
            CharacterDisplay.Controls.Remove(CD)
        Next
        TLst.Clear()

        'CharacterDisplay.Controls.Clear()
        Dim SelAction As Action = Nothing
        If selectedCData IsNot Nothing Then SelAction = selectedCData.WhoAmI
        selectedCData = Nothing
        CharacterDisplay.Refresh()
        If GI.Actions.Count = 0 Then Exit Sub
        GI.Actions = (From a In GI.Actions Order By a.EndTime Select a).ToList
        Dim Lst As DisplayCharacterData = Nothing
        Dim TCD As New DisplayCharacterData(GI.Actions(GI.Actions.Count - 1))
        Dim MP As Integer = CharacterDisplay.Width - TCD.Width - 10 - 25
        TCD.Dispose()
        TCD = Nothing
        Dim BT As Double = GI.Actions(0).EndTime

        Dim RT As Double
        If GI.Actions(GI.Actions.Count - 1).EndTime = BT Then
            RT = MP / (BT + 0.000001 - BT)
        Else
            RT = MP / (GI.Actions(GI.Actions.Count - 1).EndTime - BT)
        End If
        Dim Act As Action
        For Each Act In GI.Actions
            Found = False
            For Each CD In CharacterDisplay.Controls
                If CD.WhoAmI Is Act Then
                    Found = True
                    Exit For
                End If
            Next
            If Not Found Then
                CD = New DisplayCharacterData(Act)
                AddHandler CD.Selected, AddressOf OnCharacterClick
                AddHandler CD.ActorEdited, AddressOf OnActorEdited
                CharacterDisplay.Controls.Add(CD)
            Else
                CD.Display()
            End If
            If Lst IsNot Nothing Then
                CD.Top = Lst.Top + Lst.Height + 10
            Else
                CD.Top = 10
            End If
            CD.Left = (Act.EndTime - BT) * RT + 10

            If Act Is SelAction Then
                selectedCData = CD
            End If
            Lst = CD
        Next
        CharacterDisplay.Refresh()
    End Sub
    Private Sub displayChars()
        If GI.Chars.Count = 0 Then Exit Sub
        ListBox1.Items.Clear()
        Dim Ch As Actor
        For Each Ch In GI.Chars
            ListBox1.Items.Add(Ch)
        Next


    End Sub
    Private Sub OnActorEdited(ByVal Who As Actor)
        Who.HandleInitChange(GI.CurrentTime)
        If CurAct Is Nothing Then Exit Sub
        If ListBox5.SelectedItem Is Nothing Then Exit Sub
        CurAct.CurrentModifier = Val(ListBox4.SelectedItem)
        CurAct.CurrentAttack = ListBox5.SelectedItem
        CurAct.WhoIsActing.SetActionTime(CurAct, GI.CurrentTime)
        DisplayActions()
        'MoveNext()
        'DisplayActions()
        'Dim CD As DisplayCharacterData = Nothing
        'Dim TLst As New ArrayList
        'Dim Found As Boolean = False
        'For Each CD In CharacterDisplay.Controls
        ' CD.Display()
        ' Next
    End Sub
    Private Sub OnCharacterClick(ByVal Who As DisplayCharacterData)
        ListBox1.SelectedItem = Who.WhoAmI.WhoIsActing
        selectedCData = Who
        Panel2.Controls.Clear()
        Dim NexAct As Action = Who.WhoAmI
        If NexAct.Type = ActionType.Attack Then
            Panel2.Visible = True
            DisplayAttack1 = New DisplayAttack(DB, NexAct.CurrentAttack)
            DisplayAttack1.Dock = DockStyle.Fill
            DisplayAttack1.Enabled = False
            Panel2.Controls.Add(DisplayAttack1)
        Else
            Panel2.Visible = False
        End If
        CharacterDisplay.Refresh()
    End Sub

    Private Sub CharacterDisplay_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles CharacterDisplay.Paint
        Dim gr As Graphics = e.Graphics
        gr.Clear(CharacterDisplay.BackColor)
        If selectedCData IsNot Nothing Then
            Dim P As New Pen(Color.Blue, 10)
            gr.DrawRectangle(P, selectedCData.Left, selectedCData.Top, selectedCData.Width, selectedCData.Height)
            P.Dispose()
        End If
    End Sub

    Private Sub ListBox2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox2.SelectedIndexChanged
        Dim act As BaseAction
        ListBox3.Items.Clear()
        Dim Ga As ActionGroup = ListBox2.SelectedItem
        If Ga Is Nothing Then Exit Sub
        For Each act In Ga.Actions
            ListBox3.Items.Add(act)
        Next
        ListBox4.SelectedItem = "0"
    End Sub

    Private Sub ListBox3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox3.SelectedIndexChanged
        Dim Car As Actor = ListBox1.SelectedItem
        If Car Is Nothing Then Exit Sub
        Dim Act As BaseAction = ListBox3.SelectedItem
        If Act Is Nothing Then Exit Sub
        If CurAct IsNot Nothing Then GI.Actions.Remove(CurAct)
        CurAct = Act.GetStandardAction(Car.CurrentAction, Car)
        'CurAct.WhoIsActing = Car
        'Dim CM As Double = Car.CurModifier
        CurAct.CurrentModifier = Val(ListBox4.SelectedItem)
        Car.SetActionTime(CurAct, GI.CurrentTime)
        If CurAct.Type = ActionType.Spell AndAlso CurAct.EndTime < Car.NextSpellTime Then
            CurAct.Note = "Spell cannot go off till " & Car.NextSpellTime.ToString("0.00")
            CurAct.State = ActionProblem.IsWarning
        Else
            CurAct.Note = ""
        End If
        ListBox5.Items.Clear()
        If CurAct.Type = ActionType.Attack Then
            Dim atk, CurAtk As Attack
            CurAtk = Nothing
            atk = Nothing
            For Each atk In Car.Attacks
                ListBox5.Items.Add(atk)
            Next
            If Car.BaseCreature IsNot Nothing Then
                If selectedCData.WhoAmI.Type = ActionType.Attack AndAlso selectedCData.WhoAmI.CritGiven AndAlso selectedCData.WhoAmI.CurrentAttack.NextRoundSuccess IsNot Nothing Then
                    CurAtk = selectedCData.WhoAmI.CurrentAttack.NextRoundSuccess
                Else
                    Dim Roll As Integer = RollD100()
                    Dim Cnt As Integer = 0
                    For Each atk In Car.Attacks
                        Cnt += atk.PercentChance
                        If Cnt >= Roll Then
                            CurAtk = atk
                            Exit For
                        End If
                    Next
                    If CurAtk Is Nothing Then
                        CurAtk = Car.Attacks(Car.Attacks.Count - 1)
                    End If
                End If

            Else
                If Car.Attacks.Count > 0 Then CurAtk = Car.Attacks(0)
            End If
            CurAct.CurrentAttack = CurAtk
            CurAct.WhoIsActing.SetActionTime(CurAct, GI.CurrentTime)
            'DisplayActions()
            ListBox5.SelectedItem = CurAtk
            ListBox5.Visible = True
        Else
            ListBox5.Visible = False
        End If
        GI.Actions.Add(CurAct)
        'Car.CurModifier = CM
        Call Me.DisplayActions()
        Button1.Focus()
    End Sub
    Private Sub PulseEvent()
        GI.Actions = (From a In GI.Actions Order By a.EndTime Select a).ToList
        'If MD.Actions.Count = 0 Then Exit Sub
        If GI.Actions.Count > 0 Then
            GI.CurrentTime = GI.Actions(0).EndTime
            If GI.Actions(0).Type = ActionType.Spell Then
                Dim Ch As Actor = GI.Actions(0).WhoIsActing
                Ch.NextSpellTime = Ch.CalculateTimeRequired(10, 0, False, New Attack) + GI.CurrentTime
            End If
        End If
        Label1.Text = GI.CurrentTime.ToString("0.00")
        Call Me.DisplayActions()
        If GI.Actions.Count > 0 Then
            Dim NexAct As Action = GI.Actions(0)
            If Not NexAct.CharacterAction Then
                NexAct.HandleAction(GI)
                If Not NexAct.Reoccuring Then GI.Actions.Remove(NexAct)
                Call PulseEvent()
            ElseIf NexAct.Reoccuring Then
                NexAct.HandleAction(GI)
                Call PulseEvent()
            End If
        End If
    End Sub
    Private Sub MoveNext()
        ListBox3.SelectedIndex = -1

        Call PulseEvent()

        If GI.Actions.Count = 0 Then Exit Sub

        Dim CD As DisplayCharacterData
        Dim NexAct As Action = Nothing
        NexAct = GI.Actions(0)

        For Each CD In CharacterDisplay.Controls
            If CD.WhoAmI Is NexAct Then
                selectedCData = CD
                Panel2.Controls.Clear()
                'Dim NexAct As Action = Who.WhoAmI
                If NexAct.Type = ActionType.Attack Then
                    Panel2.Visible = True
                    DisplayAttack1 = New DisplayAttack(DB, NexAct.CurrentAttack)
                    DisplayAttack1.Dock = DockStyle.Fill
                    DisplayAttack1.Enabled = False
                    Panel2.Controls.Add(DisplayAttack1)
                Else
                    Panel2.Visible = False
                End If
                'Exit For
            End If
            CD.Display()
        Next
        ListBox1.SelectedItem = selectedCData.WhoAmI.WhoIsActing
        Dim Act As BaseAction

        Dim NAct As Action = Nothing
        If NexAct.Base IsNot Nothing AndAlso NexAct.Base.NextAction IsNot Nothing Then
            NAct = NexAct.Base.NextAction.GetStandardAction(NexAct, NexAct.WhoIsActing)
        End If
        If NAct Is Nothing Then NAct = NexAct
        If NAct.Base IsNot Nothing Then
            ListBox2.SelectedItem = NAct.Base.Group
        Else
            ListBox2.SelectedIndex = 0
        End If
        For Each Act In ListBox3.Items
            If NAct.Base IsNot Nothing AndAlso Act.Name.ToUpper = NAct.Base.Name.ToUpper Then
                ListBox3.SelectedItem = Act
                Exit For
            End If
        Next
        CharacterDisplay.Refresh()

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If CurAct IsNot Nothing Then
            'CurAct.WhoIsActing.CurModifier = Val(ListBox4.SelectedItem)
            If CurAct.Type = ActionType.Spell AndAlso CurAct.WhoIsActing.NextSpellTime > CurAct.EndTime Then
                Dim ch As Actor = CurAct.WhoIsActing
                Dim m As Integer
                Dim F As Boolean = False
                For m = 0 To 30 Step 10
                    CurAct.CurrentModifier = m
                    ch.SetActionTime(CurAct, GI.CurrentTime)
                    If ch.NextSpellTime <= CurAct.EndTime Then
                        F = True
                        Exit For
                    End If
                Next
                If Not F Then
                    CurAct.EndTime = ch.NextSpellTime
                End If
                CurAct.Note = ""
                CurAct.State = ActionProblem.IsOK
            End If
            CurAct.WhoIsActing.CurrentAction(GI) = CurAct
            GI.Actions = (From a In GI.Actions Order By a.EndTime Select a).ToList
            CurAct = Nothing
        End If
        ListBox5.Items.Clear()
        ListBox5.Visible = False
        ListBox5.Refresh()
        MoveNext()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        ListBox3.SelectedIndex = -1
        Dim DF As New DamageForm(GI, ListBox1.SelectedItem)
        DF.ShowDialog()
        MoveNext()
    End Sub

    Private Sub btnCast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCast.Click
        ListBox3.SelectedIndex = -1
        Dim DF As New DlgSpellCast(DB, GI, ListBox1.SelectedItem)
        DF.ShowDialog()
        MoveNext()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        MsgBox(RollD100OpenEnded)
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        MsgBox(RollD100)
    End Sub

    Private Sub PreBuiltCharacterToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PreBuiltCharacterToolStripMenuItem.Click
        Dim F As New EditPreBuiltChar(DB, GI)
        F.ShowDialog()
        F.Dispose()
        F = Nothing
        Call displayChars()
        Call DisplayActions()
        'If Not Started Then
        MoveNext()
        'Started = True
        'End If
    End Sub

    Private Sub Remove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Remove.Click
        If selectedCData.WhoAmI.WhoIsActing.CurrentAction Is selectedCData.WhoAmI Then
            Dim Ch As Actor = ListBox1.SelectedItem
            If Ch Is Nothing Then Exit Sub
            ListBox1.Items.Remove(Ch)
            Dim Act As Action
            Dim RList As New List(Of Action)
            For Each Act In GI.Actions
                If Act.WhoIsActing Is Ch Then
                    RList.Add(Act)
                End If
            Next
            For Each Act In RList
                GI.Actions.Remove(Act)
            Next
            RList.Clear()
            GI.Chars.Remove(Ch)
        Else
            selectedCData.WhoAmI.HandleAction(GI)
            GI.Actions.Remove(selectedCData.WhoAmI)
        End If
        MoveNext()

    End Sub

    Private Sub Reset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Reset.Click
        GI.Actions.Clear()
        GI.Chars.Clear()
        GI.CurrentTime = 0
        ListBox1.Items.Clear()
        MoveNext()
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        'Dim Ch As Character = ListBox1.SelectedItem
        'If Ch Is Nothing Then Exit Sub
        'Dim t As String
        'For Each t In ListBox4.Items
        '    If t = Ch.CurModifier.ToString Then
        '        ListBox4.SelectedItem = t
        '        Exit For
        '    End If
        'Next
    End Sub

    Private Sub ListBox4_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox4.SelectedIndexChanged
        If CurAct Is Nothing Then Exit Sub
        CurAct.CurrentModifier = Val(ListBox4.SelectedItem)
        CurAct.WhoIsActing.SetActionTime(CurAct, GI.CurrentTime)
        DisplayActions()
        'MoveNext()
    End Sub

    Private Sub ListBox5_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox5.SelectedIndexChanged
        If CurAct Is Nothing Then Exit Sub
        If ListBox5.SelectedItem Is Nothing Then Exit Sub
        CurAct.CurrentModifier = Val(ListBox4.SelectedItem)
        CurAct.CurrentAttack = ListBox5.SelectedItem
        CurAct.WhoIsActing.SetActionTime(CurAct, GI.CurrentTime)
        DisplayActions()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim Ch As Actor = ListBox1.SelectedItem
        If Ch Is Nothing Then Exit Sub
        Dim DSM As New DlgStunnedManeuvering(Ch, GI)
        DSM.ShowDialog()
        DisplayActions()
    End Sub

    'Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    'Dim Creat As Creature
    '    'For Each Creat In Creature.getcreatures
    '    '    Creat.Delete()
    '    'Next
    '    ''Public ArmorList As New List(Of Armor)
    '    'Dim Arm As Armor
    '    'For Each Arm In Armor.GetArmors
    '    '    Arm.Delete()
    '    'Next
    '    ''Public PreBuiltCharsList As New List(Of PreBuiltChar)
    '    'Dim PBC As PreBuiltChar
    '    'For Each PBC In PreBuiltChar.GetPreBuiltChars
    '    '    PBC.Delete()
    '    'Next
    '    ''Public WeaponList As New List(Of Weapon)
    '    'Dim Weap As Weapon
    '    'For Each Weap In Weapon.GetWeapons
    '    '    Weap.Delete()
    '    'Next
    '    ''Public WeaponList As New List(Of Weapon)
    '    Dim ActGroup As ActionGroup
    '    'For Each ActGroup In ActionGroup.GetActionGroups
    '    '    ActGroup.Delete()
    '    'Next

    '    'For Each Creat In MD.CreatureList
    '    '    Creat.Save()
    '    'Next

    '    'For Each PBC In MD.PreBuiltCharsList
    '    '    PBC.Save()
    '    'Next

    '    'For Each Arm In MD.ArmorList
    '    '    Arm.Save()
    '    'Next

    '    'For Each Weap In MD.WeaponList
    '    '    Weap.Save()
    '    'Next

    '    For Each ActGroup In RMSS.ActionGroups
    '        ActGroup.Save()
    '    Next
    'End Sub

    
End Class
'Public Class ActionSorter
'    Implements IComparer(Of Action)

'    Public Function Compare(ByVal x As Action, ByVal y As Action) As Integer Implements System.Collections.Generic.IComparer(Of Action).Compare
'        If x.EndTime > y.EndTime Then
'            Return 1
'        ElseIf x.EndTime < y.EndTime Then
'            Return -1
'        Else
'            Return 0
'        End If
'    End Function
'End Class