Public Class DamageForm
    Private GI As GameInstance

    Private CurChar As Actor

    Public Sub New(ByVal Thegi As GameInstance, ByVal CurrentCharacter As Actor)
        Me.InitializeComponent()
        gi = Thegi
        CurChar = CurrentCharacter
    End Sub
    Private Sub Ok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Ok.Click
        Dim Attacker As Actor = ListBox1.SelectedItem
        Dim Defender As Actor = ListBox2.SelectedItem
        If Attacker Is Nothing OrElse Defender Is Nothing Then Exit Sub
        Dim CT As CritAffects
        Defender.HitsRemaining -= Val(Damage.Text)
        If IsCritical.Checked Then
            Attacker.CurrentAction.CritGiven = True
            Defender.HitsRemaining -= Val(Me.AdditionalHits.Text)
            If Val(Me.StunRounds.Text) > 0 Then
                CT = New CritAffects
                CT.IsStunned = True
                GI.AddCritToChar(Defender, CT, Val(Me.StunRounds.Text))
            End If
            If Val(Me.RoundsMustParry.Text) > 0 Then
                CT = New CritAffects
                CT.Parry = CritAffects.ParryType.Must_Parry
                CT.ParryNegative = Val(Me.MustParryNeg.Text)
                GI.AddCritToChar(Defender, CT, Val(Me.RoundsMustParry.Text))
            End If
            If Val(Me.RoundsNoParry.Text) > 0 Then
                CT = New CritAffects
                CT.Parry = CritAffects.ParryType.No_Parry
                GI.AddCritToChar(Defender, CT, Val(Me.RoundsNoParry.Text))
            End If
            If Val(Me.NegBonus.Text) <> 0 Then
                If Val(Me.NegRounds.Text) = 0 Then
                    Defender.CritNegatives += Val(NegBonus.Text)
                Else
                    CT = New CritAffects
                    CT.Negative = Val(Me.NegBonus.Text)
                    GI.AddCritToChar(Defender, CT, Val(Me.NegRounds.Text))
                End If
            End If
            If Val(Me.PosBonus.Text) <> 0 Then
                If Val(Me.PosRounds.Text) = 0 Then
                    CT = New CritAffects
                    CT.Negative = Val(Me.PosBonus.Text)
                    GI.AddCritToChar(Attacker, CT, 1)
                Else
                    CT = New CritAffects
                    CT.Negative = Val(Me.PosBonus.Text)
                    GI.AddCritToChar(Attacker, CT, Val(Me.PosRounds.Text))
                End If
            End If
            If Val(Bleeding.Text) > 0 Then
                Dim BA As New BleedAction(Defender, GI.CurrentTime, Val(Bleeding.Text))
                GI.Actions.Add(BA)
            End If
        End If
        Defender.HandleInitChange(GI.CurrentTime)
        If Defender.HitsRemaining <= 0 Then
            Defender.HandleDeath(GI)
        End If
        Me.Hide()
    End Sub

    Private Sub DamageForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim Ch As Actor
        For Each Ch In GI.Chars
            ListBox1.Items.Add(Ch)
            ListBox2.Items.Add(Ch)
        Next
        ListBox1.SelectedItem = CurChar
    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Me.Hide()
    End Sub
End Class