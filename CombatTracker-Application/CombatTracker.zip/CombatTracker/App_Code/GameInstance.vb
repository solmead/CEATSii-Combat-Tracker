<Serializable()> Public Class GameInstance
    Public Chars As New List(Of Actor)
    Public CurrentTime As Double = 0
    Public Actions As New List(Of Action)
    Public Sub AddCritToChar(ByVal Ch As Actor, ByVal Crit As CritAffects, ByVal Rounds As Integer)
        Dim flag As Boolean = Ch.CurrentCrits Is Nothing
        Ch.AddRoundsCritAffects(Crit, Rounds, Me.CurrentTime)
        If flag Then
            Dim CA As New CritAction(Ch, Me.CurrentTime)
            Me.Actions.Add(CA)
        End If
    End Sub
    Public Sub RemoveCritsFromChar(ByVal Ch As Actor, ByVal Count As Integer)
        Dim flag As Boolean = Ch.CurrentCrits Is Nothing
        If Not flag Then
            Dim Act As Action
            For Each Act In Me.Actions
                If TypeOf (Act) Is CritAction Then
                    Dim CAct As CritAction = Act
                    If CAct.TheCritical Is Ch.CurrentCrits Then
                        Me.Actions.Remove(Act)
                        Exit For
                    End If
                End If
            Next
            Dim a As Integer
            For a = 1 To Count
                Ch.RemoveCrit(Me.CurrentTime)
            Next
            If Ch.CurrentCrits IsNot Nothing Then
                Dim CA As New CritAction(Ch, Me.CurrentTime)
                Me.Actions.Add(CA)
            End If
        End If
    End Sub
    Public Sub RemoveCritFromChar(ByVal Ch As Actor)
        Dim flag As Boolean = Ch.CurrentCrits Is Nothing
        If Not flag Then
            Dim Act As Action
            For Each Act In Me.Actions
                If TypeOf (Act) Is CritAction Then
                    Dim CAct As CritAction = Act
                    If CAct.TheCritical Is Ch.CurrentCrits Then
                        Me.Actions.Remove(Act)
                        Exit For
                    End If
                End If
            Next
            Ch.RemoveCrit(Me.CurrentTime)
            If Ch.CurrentCrits IsNot Nothing Then
                Dim CA As New CritAction(Ch, Me.CurrentTime)
                Me.Actions.Add(CA)
            End If
        End If
    End Sub

    Public Sub Check()
        If Actions Is Nothing Then Actions = New List(Of Action)
        'If PreBuiltCharsList Is Nothing Then PreBuiltCharsList = New List(Of Character)
    End Sub
    Public Sub Save()
        'Handler.SaveToFile(Me, New System.IO.FileInfo(My.Application.Info.DirectoryPath & "\datafile.ser"))
    End Sub
End Class
