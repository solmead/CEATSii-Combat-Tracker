Public Class CritAffects
    Public Enum ParryType
        Fine
        Must_Parry
        No_Parry
    End Enum
    Public IsStunned As Boolean
    Public Parry As ParryType
    Public ParryNegative As Integer
    Public Negative As Integer
    Public TimeStart As Double
    Public TimeEnd As Double
    Public Function Clone() As CritAffects
        Dim CA As New CritAffects
        CA.IsStunned = IsStunned
        CA.Parry = Parry
        CA.ParryNegative = ParryNegative
        CA.TimeEnd = TimeEnd
        Return CA
    End Function
End Class
