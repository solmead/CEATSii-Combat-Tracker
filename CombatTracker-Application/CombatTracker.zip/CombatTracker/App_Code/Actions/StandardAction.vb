
<Serializable()> Public Class StandardAction
    Inherits Action


    Public Overrides ReadOnly Property CharacterAction() As Boolean
        Get
            Return True
        End Get
    End Property

    Public Overrides Function Clone() As Action
        Dim Act As New StandardAction
        Me.CloneMe(Act)
        Return Act
    End Function

    Public Overrides Sub HandleAction(ByVal GI As GameInstance)

    End Sub

    Public Overrides Sub RefreshData()

    End Sub
End Class
