﻿Public Class PrepAction
    Inherits Action
    Public CurRound As Integer = 1

    Public Sub New(ByVal PrevRounds As Integer)
        CurRound = PrevRounds
    End Sub

    Public Overrides ReadOnly Property CharacterAction() As Boolean
        Get
            Return True
        End Get
    End Property

    Public Overrides Function Clone() As Action
        Dim Act As New PrepAction(CurRound)
        Me.CloneMe(Act)
        Return Act
    End Function

    Public Overrides Sub HandleAction(ByVal GI As GameInstance)

    End Sub

    Public Overrides Sub RefreshData()

    End Sub
End Class
