
<Serializable()> Public Class DeathAction
    Inherits Action
    Public Cnt As Integer = 0
    Private Sub New()

    End Sub
    Public Sub New(ByVal TheChar As Actor, ByVal CurrentTime As Double)
        WhoIsActing = TheChar
        Me.Name = TheChar.Name & " is unconcious"
        Me.Note = ""
        Me.BasePercent = 1
        Me.StartTime = CurrentTime
        Me.EndTime = TheChar.CalculateTimeRequiredNonEnc(BaseRoundTime) + CurrentTime
    End Sub
    Public Overrides ReadOnly Property Reoccuring() As Boolean
        Get
            Return WhoIsActing.HitsRemaining <= 0
        End Get
    End Property
    Public Overrides ReadOnly Property CharacterAction() As Boolean
        Get
            Return True
        End Get
    End Property

    Public Overrides Sub HandleAction(ByVal GI As GameInstance)
        If WhoIsActing.HitsRemaining < -WhoIsActing.ConStat Then
            Me.Name = WhoIsActing.Name & " is Dead"
            Cnt += 1
            Note = "Rounds of Death:" & Cnt
        End If
        Me.EndTime = WhoIsActing.CalculateTimeRequiredNonEnc(BaseRoundTime) + GI.CurrentTime
        'WhoIsActing.HandleInitChange(MD)
    End Sub

    Public Overrides Sub RefreshData()

    End Sub

    Public Overrides Function Clone() As Action
        Dim Act As New DeathAction
        Me.CloneMe(Act)
        Return Act
    End Function
End Class
