
<Serializable()> Public Class CritAction
    Inherits Action
    Public TheCritical As CritAffects
    'Private Ch As Character
    Private Sub New()

    End Sub
    Public Sub New(ByVal TheChar As Actor, ByVal CurrentTime As Double)
        WhoIsActing = TheChar
        Dim Ch As Actor = WhoIsActing
        TheCritical = Ch.CurrentCrits
        'Me.WhoIsActing = Ch
        Dim N1, N2, N3, N4 As String
        N1 = ""
        N2 = ""
        N3 = ""
        N4 = ""
        If Ch.StunRounds > 0 Then
            N1 = Ch.StunRounds & " Rnds of Stun"
        End If
        If Ch.ParryRounds > 0 Then
            N2 = Ch.ParryRounds & " Rnds of Parry"
        End If
        If Ch.NegativeRounds > 0 Then
            N3 = Ch.NegativeRounds & " Rnds at Mods"
        End If
        Me.Note = N1 & " " & N2 & " " & N3
        Me.BasePercent = 1
        Me.StartTime = CurrentTime
        Me.EndTime = TheCritical.TimeEnd
        If TheCritical.IsStunned Then
            Me.Name = "Stun"
        End If
        If TheCritical.Parry <> CritAffects.ParryType.Fine Then
            If Me.Name.Length > 0 Then
                Me.Name = Me.Name & " & " & TheCritical.Parry.ToString
            Else
                Me.Name = TheCritical.Parry.ToString
            End If
        End If
        Me.Name = Me.Name & " On " & Ch.Name
    End Sub
    Public Overrides Sub RefreshData()
        Dim Ch As Actor = WhoIsActing
        Dim N1, N2, N3 As String
        N1 = ""
        N2 = ""
        N3 = ""
        If Ch.StunRounds > 0 Then
            N1 = Ch.StunRounds & " Rnds of Stun"
        End If
        If Ch.ParryRounds > 0 Then
            N2 = Ch.ParryRounds & " Rnds of Parry"
        End If
        If Ch.NegativeRounds > 0 Then
            N3 = Ch.NegativeRounds & " Rnds at Mods"
        End If
        Me.Note = N1 & " " & N2 & " " & N3
        Me.BasePercent = 1
        Me.EndTime = TheCritical.TimeEnd
        Me.Name = ""
        If TheCritical.IsStunned Then
            Me.Name = "Stun"
        End If
        If TheCritical.Parry <> CritAffects.ParryType.Fine Then
            If Me.Name.Length > 0 Then
                Me.Name = Me.Name & " & " & TheCritical.Parry.ToString
            Else
                Me.Name = TheCritical.Parry.ToString
            End If
        End If
        Me.Name = Me.Name & " On " & Ch.Name
    End Sub
    Public Overrides ReadOnly Property CharacterAction() As Boolean
        Get
            Return False
        End Get
    End Property
    Public Overrides Sub HandleAction(ByVal GI As GameInstance)
        Dim Ch As Actor = WhoIsActing
        GI.RemoveCritFromChar(Ch)
    End Sub

    Public Overrides Function Clone() As Action
        Dim Act As New CritAction
        Me.CloneMe(Act)
        Return Act
    End Function
End Class
