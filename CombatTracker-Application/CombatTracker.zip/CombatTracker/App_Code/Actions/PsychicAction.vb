
Public Class PsychicAction
    Inherits Action
    Private CurRound As Integer = 1
    Private TotRounds As Integer = 0
    Private LevDiff As Integer
    Private mDB As RMSSDataDataContext
    Private Sub New()

    End Sub
    Public Sub New(ByVal DB As RMSSDataDataContext, ByVal TheChar As Actor, ByVal CurrentTime As Double, ByVal PsychicLevel As Integer)
        mDB = DB
        WhoIsActing = TheChar
        LevDiff = TheChar.Level - PsychicLevel
        TotRounds = PsychicRefractoryPeriodChart.LookupRoundsToZero(DB, LevDiff)
        Me.Name = "Psychic Recovery on " & TheChar.Name
        Me.Note = "Round " & CurRound & " of " & TotRounds
        Me.BasePercent = 1
        Me.StartTime = CurrentTime
        Me.EndTime = TheChar.CalculateTimeRequiredForSpells(BaseRoundTime) + CurrentTime
        TheChar.CritNegatives += PsychicRefractoryPeriodChart.LookupNegative(DB, LevDiff, CurRound)
    End Sub
    Public Overrides ReadOnly Property CharacterAction() As Boolean
        Get
            Return False
        End Get
    End Property

    Public Overrides Function Clone() As Action
        Dim Act As New PsychicAction
        Me.CloneMe(Act)
        Return Act
    End Function

    Public Overrides Sub HandleAction(ByVal GI As GameInstance)
        WhoIsActing.CritNegatives -= PsychicRefractoryPeriodChart.LookupNegative(mDB, LevDiff, CurRound)
        CurRound += 1
        WhoIsActing.CritNegatives += PsychicRefractoryPeriodChart.LookupNegative(mDB, LevDiff, CurRound)
        Me.EndTime = WhoIsActing.CalculateTimeRequiredForSpells(BaseRoundTime) + GI.CurrentTime
        Me.Note = "Round " & CurRound & " of " & TotRounds

    End Sub
    Public Overrides ReadOnly Property Reoccuring() As Boolean
        Get
            Return CurRound <= TotRounds
        End Get
    End Property
    Public Overrides Sub RefreshData()

    End Sub
End Class
