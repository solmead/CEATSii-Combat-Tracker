<Serializable()> Public Class BleedAction
    Inherits Action
    Public Bleeder As Integer
    Public Cnt As Integer = 0
    Private Sub New()

    End Sub
    Public Sub New(ByVal TheChar As Actor, ByVal CurrentTime As Double, ByVal BleedRate As Integer)
        WhoIsActing = TheChar
        Bleeder = BleedRate
        Me.Name = TheChar.Name & " bleeding at " & BleedRate
        Me.Note = ""
        Me.BasePercent = 1
        Me.StartTime = CurrentTime
        Me.EndTime = TheChar.CalculateTimeRequiredNonEnc(BaseRoundTime) + CurrentTime
    End Sub
    Public Overrides ReadOnly Property Reoccuring() As Boolean
        Get
            Return True
        End Get
    End Property
    Public Overrides ReadOnly Property CharacterAction() As Boolean
        Get
            Return False
        End Get
    End Property

    Public Overrides Sub HandleAction(ByVal GI As GameInstance)
        WhoIsActing.HitsRemaining -= Bleeder
        Cnt += 1
        Note = "Rounds of Bleeding:" & Cnt
        Me.EndTime = WhoIsActing.CalculateTimeRequiredNonEnc(BaseRoundTime) + GI.CurrentTime
        WhoIsActing.HandleInitChange(GI.CurrentTime)
        If WhoIsActing.Type = CharacterType.PC Then
            MsgBox(WhoIsActing.Name & " bleeds " & Bleeder)
        End If
        If WhoIsActing.HitsRemaining <= 0 Then
            WhoIsActing.HandleDeath(GI)
        End If
    End Sub

    Public Overrides Sub RefreshData()

    End Sub

    Public Overrides Function Clone() As Action
        Dim Act As New BleedAction
        Me.CloneMe(Act)
        Return Act
    End Function
End Class
