Public Enum ActionProblem
    IsOK
    IsWarning
    IsError
End Enum
<Serializable()> Public MustInherit Class Action

    Public EndTime As Double = 0
    Public StartTime As Double = 0
    Public Name As String = "Unknown"
    Public BasePercent As Double = 0.001
    'Public IsAttack As Boolean = False
    'Public IsSpell As Boolean = False
    Public Type As ActionType
    'Public NextActionName As String = ""
    'Public Nextaction As Action = Nothing
    Public Interrupted As Boolean = False
    Public WhoIsActing As Actor
    Public Note As String = ""
    Public State As ActionProblem = ActionProblem.IsOK
    Public CurrentModifier As Integer
    Public CurrentAttack As Attack
    Public CritGiven As Boolean
    Public Base As BaseAction
    Public MustOverride ReadOnly Property CharacterAction() As Boolean
    Public MustOverride Sub HandleAction(ByVal GI As GameInstance)
    Public MustOverride Sub RefreshData()
    Public ReadOnly Property PercentageCompleted(ByVal CurrentTime As Double) As Double
        Get
            Return (CurrentTime - StartTime) / (EndTime - StartTime)
        End Get
    End Property
    Public Overridable ReadOnly Property Reoccuring() As Boolean
        Get
            Return False
        End Get
    End Property
    Public Overrides Function ToString() As String
        Return Name
    End Function
    Public MustOverride Function Clone() As Action
    Protected Sub CloneMe(ByVal NewAct As Action)
        'NewAct.Group = Group
        NewAct.EndTime = EndTime
        NewAct.Name = Name
        NewAct.BasePercent = BasePercent
        NewAct.Type = Type
        'NewAct.IsAttack = IsAttack
        NewAct.Interrupted = Interrupted
        NewAct.WhoIsActing = WhoIsActing
        NewAct.Note = Note
        'NewAct.IsSpell = IsSpell
        'NewAct.Nextaction = Nextaction
        'NewAct.NextActionName = NextActionName
        NewAct.CurrentModifier = Me.CurrentModifier
        NewAct.CurrentAttack = Me.CurrentAttack
        NewAct.State = Me.State
        NewAct.CritGiven = Me.CritGiven
        NewAct.StartTime = Me.StartTime
    End Sub
End Class
