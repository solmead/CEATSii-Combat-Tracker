
Public Class SpellAction
    Inherits Action
    Private IsHasted As Boolean
    Private IsSlowed As Boolean
    Private HPercent As Integer
    Private Sub New()

    End Sub
    ''' <summary>
    ''' Create new spell action
    ''' </summary>
    ''' <param name="TheChar">The caracter that this action applies to</param>
    ''' <param name="CurrentTime">CurrentTime</param>
    ''' <param name="Name">Name of spell</param>
    ''' <param name="Duration">Duration in rounds</param>
    ''' <param name="HastePercent">Percentage action per round 50 to 200</param>
    ''' <remarks></remarks>
    Public Sub New(ByVal TheChar As Actor, ByVal Caster As Actor, ByVal CurrentTime As Double, ByVal Name As String, ByVal Duration As Integer, ByVal HastePercent As Integer)
        WhoIsActing = TheChar
        HPercent = HastePercent
        IsHasted = HastePercent > 0
        IsSlowed = HastePercent < 0
        If TheChar IsNot Nothing Then
            Me.Name = "Spell:" & Name & " cast"
            Me.Note = "on " & TheChar.Name
        Else
            Me.Name = "Spell:" & Name & " cast"
        End If
        'Me.Note = ""
        Me.BasePercent = Duration
        Me.StartTime = CurrentTime
        Me.EndTime = Caster.CalculateTimeRequiredForSpells(BaseRoundTime * Duration) + CurrentTime
        If IsHasted OrElse IsSlowed Then
            WhoIsActing.PercentAction *= (HastePercent / 100)
            WhoIsActing.HandleInitChange(CurrentTime)

        End If
    End Sub
    Public Overrides ReadOnly Property CharacterAction() As Boolean
        Get
            Return False
        End Get
    End Property

    Public Overrides Function Clone() As Action
        Dim Act As New SpellAction
        Me.CloneMe(Act)
        Return Act
    End Function

    Public Overrides Sub HandleAction(ByVal GI As GameInstance)
        If IsHasted OrElse IsSlowed Then
            WhoIsActing.PercentAction /= (HPercent / 100)
            WhoIsActing.HandleInitChange(GI.CurrentTime)
        End If
    End Sub

    Public Overrides Sub RefreshData()

    End Sub
End Class
