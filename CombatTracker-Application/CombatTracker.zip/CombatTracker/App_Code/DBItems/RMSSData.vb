Partial Class RMSSDataDataContext

End Class

