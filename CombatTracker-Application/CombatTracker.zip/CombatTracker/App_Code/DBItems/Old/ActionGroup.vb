
'Public Class ActionGroupOld

'    Private m_ID As Integer
'    Private m_Name As String
'    Private m_Actions As List(Of BaseActionOld)
'    Public Property ID() As Integer
'        Get
'            Return m_ID
'        End Get
'        Set(ByVal Value As Integer)
'            m_ID = Value
'        End Set
'    End Property

'    Public Property Name() As String
'        Get
'            Return m_Name
'        End Get
'        Set(ByVal Value As String)
'            m_Name = Value
'        End Set
'    End Property

'    Public Property Actions() As List(Of BaseActionOld)
'        Get
'            If m_Actions Is Nothing Then
'                m_Actions = BaseActionOld.GetActionsForActionGroup(Me)
'            End If
'            Return m_Actions
'        End Get
'        Set(ByVal Value As List(Of BaseActionOld))
'            m_Actions = Value
'        End Set
'    End Property


'    Public Overrides Function ToString() As String
'        Return Name
'    End Function

'    Public Sub New()

'    End Sub
'    Public Sub Delete()
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "Delete From ActionGroups where ID=@ID"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'        Cmd.ExecuteNonQuery()
'        Dim Act As BaseActionOld
'        For Each Act In Actions
'            Act.Delete()
'        Next
'        ID = 0
'        If Flagg Then DB.ConnEnd()
'    End Sub
'    Public Sub Save()
'        Dim DBEn As New DBEnabled
'        Dim Flagg As Boolean = DBEn.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        If ID = 0 Then
'            SQL = "Insert into ActionGroups (Name) values (@Name); Select @@Identity"
'        Else
'            SQL = "Update ActionGroups Set Name=@Name Where ID=@ID"
'        End If
'        Cmd = New SqlClient.SqlCommand(SQL, DBEn.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Name", Name))
'        If ID = 0 Then
'            ID = Cmd.ExecuteScalar
'        Else
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'            Cmd.ExecuteNonQuery()
'        End If
'        Dim Act As BaseActionOld
'        For Each Act In Actions
'            Act.Group = Me
'            Act.Save()
'        Next
'        If Flagg Then DBEn.ConnEnd()
'    End Sub

'    Private Sub Load(ByVal DR As DataRow)
'        'Name, MinWeight, MaxWeight, Weight, Bonus, Is2Handed, OB
'        ID = CInt(GetData(DR, "ID"))
'        Name = GetData(DR, "Name")
'    End Sub
'    Public Shared Function Load(ByVal ID As Integer) As ActionGroupOld
'        Dim DB As New DBEnabled
'        Dim CI As New ActionGroupOld
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,Name FROM ActionGroups where ID=@ID"

'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        If DT.Rows.Count > 0 Then
'            DR = DT.Rows(0)
'            CI.Load(DR)
'        End If
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return CI
'    End Function

'    Public Shared Function Find(ByVal Name As String) As ActionGroupOld
'        Dim DB As New DBEnabled
'        Dim CI As New ActionGroupOld
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,Name FROM ActionGroups where Name=@Name"

'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Name", Name))
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        If DT.Rows.Count > 0 Then
'            DR = DT.Rows(0)
'            CI.Load(DR)
'        End If
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return CI
'    End Function
'    Public Shared Function GetActionGroups() As Generic.List(Of ActionGroupOld)
'        Dim List As New Generic.List(Of ActionGroupOld)
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,Name FROM ActionGroups"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        For Each DR In DT.Rows
'            Dim CI As New ActionGroupOld
'            CI.Load(DR)
'            List.Add(CI)
'        Next
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return List
'    End Function
'    Public Shared Function GetActionGroups(ByVal DataFile As Xml.XmlDocument) As Generic.List(Of ActionGroupOld)
'        Dim List As New Generic.List(Of ActionGroupOld)

'        Dim XMl As Xml.XmlDocument
'        XMl = DataFile
'        If XMl Is Nothing Then
'            XMl = New Xml.XmlDocument
'            XMl.Load(My.Application.Info.DirectoryPath & "\datafile.xml")
'        End If

'        Dim ActList As New Generic.Dictionary(Of String, BaseActionOld)

'        Dim Act As BaseActionOld
'        Dim XMLElem, Elem2 As Xml.XmlElement
'        Dim XMLList As Xml.XmlNodeList
'        XMLList = XMl.DocumentElement.SelectNodes("Actions/Group")
'        For Each XMLElem In XMLList
'            Dim AG As New ActionGroupOld
'            AG.Name = XMLElem.GetAttribute("Name")
'            For Each Elem2 In XMLElem.ChildNodes
'                Act = New BaseActionOld
'                Dim Tstr As String
'                Act.Name = Elem2.GetAttribute("Name")
'                Act.BasePercent = CDbl(Elem2.GetAttribute("Percent"))
'                Act.IsAttack = CBool(Elem2.GetAttribute("IsAttack"))
'                Tstr = Elem2.GetAttribute("IsSpell")
'                If Tstr = "" Then Tstr = "False"
'                Act.IsSpell = CBool(Tstr)
'                Act.NextActionName = CStr(Elem2.GetAttribute("NextAction"))
'                ActList.Add(Act.Name, Act)
'                AG.Actions.Add(Act)
'            Next
'            List.Add(AG)
'        Next

'        For Each Act In ActList.Values
'            If Act.NextActionName <> "" Then
'                Act.Nextaction = ActList(Act.NextActionName)
'            End If
'        Next

'        Return List
'    End Function
'End Class
