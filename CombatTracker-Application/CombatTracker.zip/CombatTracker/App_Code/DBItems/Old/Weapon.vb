
'<Serializable()> Public Class WeaponOld
'    Implements System.Runtime.Serialization.ISerializable

'    Private m_ID As Integer
'    Private m_Name As String = ""
'    Private m_MinWeight As Integer
'    Private m_MaxWeight As Integer
'    Private m_Weight As Integer
'    Private m_Bonus As Integer
'    Private m_Is2Handed As Boolean
'    Private m_OB As Integer
'    '
'    Public Property ID() As Integer
'        Get
'            Return m_ID
'        End Get
'        Set(ByVal Value As Integer)
'            m_ID = Value
'        End Set
'    End Property

'    Public Property Name() As String
'        Get
'            Return m_Name
'        End Get
'        Set(ByVal Value As String)
'            m_Name = Value
'        End Set
'    End Property

'    Public Property MinWeight() As Integer
'        Get
'            Return m_MinWeight
'        End Get
'        Set(ByVal Value As Integer)
'            m_MinWeight = Value
'        End Set
'    End Property

'    Public Property MaxWeight() As Integer
'        Get
'            Return m_MaxWeight
'        End Get
'        Set(ByVal Value As Integer)
'            m_MaxWeight = Value
'        End Set
'    End Property

'    Public Property Weight() As Integer
'        Get
'            Return m_Weight
'        End Get
'        Set(ByVal Value As Integer)
'            m_Weight = Value
'        End Set
'    End Property

'    Public Property Bonus() As Integer
'        Get
'            Return m_Bonus
'        End Get
'        Set(ByVal Value As Integer)
'            m_Bonus = Value
'        End Set
'    End Property

'    Public Property Is2Handed() As Boolean
'        Get
'            Return m_Is2Handed
'        End Get
'        Set(ByVal Value As Boolean)
'            m_Is2Handed = Value
'        End Set
'    End Property

'    Public Property OB() As Integer
'        Get
'            Return m_OB
'        End Get
'        Set(ByVal Value As Integer)
'            m_OB = Value
'        End Set
'    End Property


'    Public Overrides Function ToString() As String
'        Return Name
'    End Function

'    Public Sub New()

'    End Sub
'    Public Sub New(ByVal info As System.Runtime.Serialization.SerializationInfo, ByVal context As System.Runtime.Serialization.StreamingContext)
'        Name = info.GetString("Name")
'        MinWeight = info.GetInt32("MinWeight")
'        MaxWeight = info.GetInt32("MaxWeight")
'        Weight = info.GetInt32("Weight")
'        Bonus = info.GetInt32("Bonus")
'        Is2Handed = info.GetBoolean("Is2Handed")
'        OB = info.GetInt32("OB")
'    End Sub


'    Public Sub Delete()
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "Delete From Weapons where ID=@ID"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'        Cmd.ExecuteNonQuery()
'        ID = 0
'        If Flagg Then DB.ConnEnd()
'    End Sub
'    Public Sub Save(Optional ByVal TiedToID As Integer = 0)
'        Dim DBEn As New DBEnabled
'        Dim Flagg As Boolean = DBEn.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        If ID = 0 Then
'            SQL = "Insert into Weapons (Name, MinWeight, MaxWeight, Weight, Bonus, Is2Handed, OB,TiedToID) values (@Name, @MinWeight, @MaxWeight, @Weight, @Bonus, @Is2Handed, @OB,@TiedToID); Select @@Identity"
'        Else
'            SQL = "Update Weapons Set Name=@Name, MinWeight=@MinWeight, MaxWeight=@MaxWeight, Weight=@Weight, Bonus=@Bonus, Is2Handed=@Is2Handed, OB=@OB,TiedToID=@TiedToID Where ID=@ID"
'        End If
'        Cmd = New SqlClient.SqlCommand(SQL, DBEn.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Name", Name))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@MinWeight", MinWeight))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@MaxWeight", MaxWeight))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Weight", Weight))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Bonus", Bonus))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Is2Handed", Is2Handed))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@OB", OB))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@TiedToID", TiedToID))
'        If ID = 0 Then
'            ID = Cmd.ExecuteScalar
'        Else
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'            Cmd.ExecuteNonQuery()
'        End If
'        If Flagg Then DBEn.ConnEnd()
'    End Sub

'    Private Sub Load(ByVal DR As DataRow)
'        'Name, MinWeight, MaxWeight, Weight, Bonus, Is2Handed, OB
'        ID = CInt(GetData(DR, "ID"))
'        Name = GetData(DR, "Name")
'        MinWeight = CInt(GetData(DR, "MinWeight"))
'        MaxWeight = CInt(GetData(DR, "MaxWeight"))
'        Weight = CInt(GetData(DR, "Weight"))
'        Bonus = CInt(GetData(DR, "Bonus"))
'        Is2Handed = CBool(GetData(DR, "Is2Handed"))
'        OB = CInt(GetData(DR, "OB"))
'    End Sub
'    Public Shared Function Load(ByVal ID As Integer) As WeaponOld
'        Dim DB As New DBEnabled
'        Dim CI As New WeaponOld
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,Name, MinWeight, MaxWeight, Weight, Bonus, Is2Handed, OB FROM Weapons where ID=@ID"

'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        If DT.Rows.Count > 0 Then
'            DR = DT.Rows(0)
'            CI.Load(DR)
'        End If
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return CI
'    End Function
'    Public Shared Function Find(ByVal Type As String) As WeaponOld
'        Dim DB As New DBEnabled
'        Dim CI As New WeaponOld
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,Name, MinWeight, MaxWeight, Weight, Bonus, Is2Handed, OB FROM Weapons where Type=@Type"

'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Type", Type))
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        If DT.Rows.Count > 0 Then
'            DR = DT.Rows(0)
'            CI.Load(DR)
'        End If
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return CI
'    End Function
'    Public Shared Function GetWeapons() As Generic.List(Of WeaponOld)
'        Dim List As New Generic.List(Of WeaponOld)
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,Name, MinWeight, MaxWeight, Weight, Bonus, Is2Handed, OB FROM Weapons"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        For Each DR In DT.Rows
'            Dim CI As New WeaponOld
'            CI.Load(DR)
'            List.Add(CI)
'        Next
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return List
'    End Function
'    Public Shared Function GetWeaponsTiedTo(ByVal TiedToID As Integer) As Generic.List(Of WeaponOld)
'        Dim List As New Generic.List(Of WeaponOld)
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,Name, MinWeight, MaxWeight, Weight, Bonus, Is2Handed, OB FROM Weapons where TiedToID=@TiedToID"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@TiedToID", TiedToID))
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        For Each DR In DT.Rows
'            Dim CI As New WeaponOld
'            CI.Load(DR)
'            List.Add(CI)
'        Next
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return List
'    End Function

'    Public Sub GetObjectData(ByVal info As System.Runtime.Serialization.SerializationInfo, ByVal context As System.Runtime.Serialization.StreamingContext) Implements System.Runtime.Serialization.ISerializable.GetObjectData

'    End Sub
'End Class
