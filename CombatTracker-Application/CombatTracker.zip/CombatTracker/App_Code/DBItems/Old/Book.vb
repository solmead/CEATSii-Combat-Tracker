'Public Class BookOld

'    Public ID As Integer
'    Public Name As String


'    Public Overrides Function ToString() As String
'        Return Name
'    End Function
'    Public Sub Delete()
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "Delete From Books where ID=@ID"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'        Cmd.ExecuteNonQuery()
'        ID = 0
'        If Flagg Then DB.ConnEnd()
'    End Sub
'    Public Sub Save()
'        Dim DBEn As New DBEnabled
'        Dim Flagg As Boolean = DBEn.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        If ID = 0 Then
'            SQL = "Insert into Books (Name) values (@Name); Select @@Identity"
'        Else
'            SQL = "Update Books Set Name=@Name Where ID=@ID"
'        End If
'        Cmd = New SqlClient.SqlCommand(SQL, DBEn.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Name", Name))
'        If ID = 0 Then
'            ID = Cmd.ExecuteScalar
'        Else
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'            Cmd.ExecuteNonQuery()
'        End If
'        If Flagg Then DBEn.ConnEnd()
'    End Sub

'    Private Sub Load(ByVal DR As DataRow)
'        'Name, MinWeight, MaxWeight, Weight, Bonus, Is2Handed, OB
'        ID = CInt(GetData(DR, "ID"))
'        Name = GetData(DR, "Name")
'    End Sub
'    Public Shared Function Load(ByVal ID As Integer) As BookOld
'        Dim DB As New DBEnabled
'        Dim CI As New BookOld
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,Name FROM Books where ID=@ID"

'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        If DT.Rows.Count > 0 Then
'            DR = DT.Rows(0)
'            CI.Load(DR)
'        End If
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return CI
'    End Function
'    Public Shared Function Find(ByVal Type As String) As BookOld
'        Dim DB As New DBEnabled
'        Dim CI As New BookOld
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,Name FROM Books where Type=@Type"

'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Type", Type))
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        If DT.Rows.Count > 0 Then
'            DR = DT.Rows(0)
'            CI.Load(DR)
'        End If
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return CI
'    End Function
'    Public Shared Function GetBooks() As Generic.List(Of BookOld)
'        Dim List As New Generic.List(Of BookOld)
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,Name FROM Books"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        For Each DR In DT.Rows
'            Dim CI As New BookOld
'            CI.Load(DR)
'            List.Add(CI)
'        Next
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return List
'    End Function


'End Class
