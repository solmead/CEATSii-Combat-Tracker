''Imports java.io
''Imports java.util.zip
''Imports com.ms.vjsharp.struct
'Imports System.Text
'Imports System.IO
''Imports MessageLogging
'Imports ICSharpCode.SharpZipLib.Checksums
'Imports ICSharpCode.SharpZipLib.Zip
'Imports ICSharpCode.SharpZipLib.GZip

'Public Class Compression
'    Private Enum CompressType As Byte
'        None = 0
'        NoCompression = 1
'        CompressedZip = 2
'        CompressedGZip = 3
'    End Enum

'    Private Function ConvertSByteToByte(ByVal InData As [SByte]()) As Byte()
'        Dim TData As Byte()
'        Try
'            Dim TmpStr As String = ""

'            ReDim TData(InData.Length - 1)
'            Dim b As Integer
'            For b = 0 To InData.Length - 1
'                If Convert.ToInt16(InData(b)) < 0 Then
'                    TData(b) = Convert.ToByte(256 + Convert.ToInt16(InData(b)))
'                Else
'                    TData(b) = Convert.ToByte(InData(b))
'                End If
'            Next
'            Return TData
'        Catch ex As Exception
'            'Logger.LogError(LoggerLevel.Email, "ConvertSByteToByte", "", ex)
'        End Try
'    End Function
'    Private Function ConvertSByteToByte(ByVal InData As [SByte](), ByVal StartPos As Long, ByVal DataLength As Long) As Byte()
'        Try
'            Dim TmpStr As String = ""
'            Dim TData As Byte()
'            ReDim TData(DataLength - 1)
'            Dim b As Integer
'            For b = StartPos To StartPos + DataLength - 1
'                If Convert.ToInt16(InData(b)) < 0 Then
'                    TData(b - StartPos) = Convert.ToByte(256 + Convert.ToInt16(InData(b)))
'                Else
'                    TData(b - StartPos) = Convert.ToByte(InData(b))
'                End If
'            Next
'            Return TData
'        Catch ex As Exception
'            'Logger.LogError(LoggerLevel.Email, "ConvertSByteToByte 3 Param", "", ex)
'        End Try
'    End Function
'    Private Function ConvertByteToSByte(ByVal InData As Byte()) As [SByte]()
'        Try
'            'Dim TmpStr As String
'            Dim TData As [SByte]()
'            ReDim TData(InData.Length - 1)
'            Dim b As Integer
'            For b = 0 To InData.Length - 1
'                If InData(b) > 127 Then
'                    TData(b) = Convert.ToSByte(InData(b) - 256)
'                Else
'                    TData(b) = Convert.ToSByte(InData(b))
'                End If
'            Next
'            Return TData
'        Catch ex As Exception
'            'Logger.LogError(LoggerLevel.Email, "ConvertByteToSByte", "", ex)
'        End Try
'    End Function
'    Private Function CompressDataZip(ByVal TheData As Byte()) As Byte()
'        Try
'            'Dim CData As SByte()
'            Dim FData As Byte()
'            Dim f As java.util.zip.Deflater = New java.util.zip.Deflater
'            Dim data As [SByte]() = ConvertByteToSByte(TheData)
'            f.setInput(data)
'            f.finish()
'            Dim MemStream As New MemoryStream
'            'Dim o As java.io.ByteArrayOutputStream = New java.io.ByteArrayOutputStream(data.Length)
'            Try
'                Dim buf As [SByte]()
'                ReDim buf(1024)
'                While (Not f.finished())
'                    ReDim buf(1024)
'                    Dim got As Integer = f.deflate(buf)
'                    MemStream.Write(ConvertSByteToByte(buf, 0, got), 0, got)
'                    'o.write(buf, 0, got)
'                End While
'            Catch ex As Exception
'                'o.close()
'            End Try
'            'CData = o.toByteArray()
'            FData = MemStream.ToArray()
'            MemStream.Close()
'            'FData = FData
'            Return FData
'        Catch ex As Exception
'            'Logger.LogError(LoggerLevel.Email, "CompressDataZip", "", ex)
'        End Try
'    End Function
'    Private Function DecompressDataZip(ByVal TheData As Byte()) As Byte()
'        Try
'            Dim f As java.util.zip.Inflater = New java.util.zip.Inflater
'            Dim FData As Byte()
'            'FData = TheData
'            Dim data As [SByte]() = ConvertByteToSByte(TheData)
'            f.setInput(data)
'            Dim MemStream As New MemoryStream

'            'Dim o As java.io.ByteArrayOutputStream = New java.io.ByteArrayOutputStream(data.Length)
'            Try
'                Dim buf As [SByte]()
'                ReDim buf(1024)
'                Dim got As Integer
'                got = 1
'                While (Not f.finished()) And got > 0
'                    got = f.inflate(buf)
'                    MemStream.Write(ConvertSByteToByte(buf, 0, got), 0, got)
'                    ReDim buf(1024)
'                    'o.write(buf, 0, got)
'                End While
'            Catch ex As Exception
'                'o.close()
'            End Try
'            'FData = ConvertSByteToByte(o.toByteArray())
'            FData = MemStream.ToArray()
'            MemStream.Close()
'            Return FData
'        Catch ex As Exception
'            'Logger.LogError(LoggerLevel.Email, "DecompressDataZip", "", ex)
'        End Try
'    End Function
'    'Public Function CompressDataZip2(ByVal TheData As Byte()) As Byte()
'    '    Try
'    '        Dim OutMemStream As New MemoryStream
'    '        Dim stmGzipArchive As Stream = New ICSharpCode.SharpZipLib.Zip.ZipOutputStream(OutMemStream)
'    '        stmGzipArchive.Write(TheData, 0, TheData.Length)
'    '        stmGzipArchive.Flush()
'    '        stmGzipArchive.Close()
'    '        Dim FinData() As Byte
'    '        FinData = OutMemStream.ToArray()
'    '        OutMemStream.Close()
'    '        Return FinData
'    '    Catch ex As Exception
'    '        'Logger.LogError(LoggerLevel.Email, "CompressDataGZip", "", ex)
'    '    End Try
'    'End Function
'    'Public Function DeCompressDataZip2(ByVal TheData As Byte()) As Byte()
'    '    Try
'    '        Dim FinData() As Byte
'    '        Dim nSize As Integer = 2048
'    '        Dim nSizeRead As Integer
'    '        Dim abyWriteData(2048) As Byte
'    '        Dim InMemStream As New MemoryStream
'    '        Dim OutMemStream As New MemoryStream
'    '        InMemStream.Write(TheData, 0, TheData.Length)
'    '        InMemStream.Flush()
'    '        InMemStream.Position = 0

'    '        Dim stmGzipArchive As Stream = New ICSharpCode.SharpZipLib.Zip.ZipInputStream(InMemStream)
'    '        While (True)
'    '            nSizeRead = stmGzipArchive.Read(abyWriteData, 0, nSize)
'    '            If nSizeRead > 0 Then
'    '                OutMemStream.Write(abyWriteData, 0, nSizeRead)
'    '            Else
'    '                Exit While
'    '            End If
'    '        End While
'    '        OutMemStream.Flush()
'    '        FinData = OutMemStream.ToArray()
'    '        OutMemStream.Close()
'    '        stmGzipArchive.Close()
'    '        Return FinData
'    '    Catch ex As Exception
'    '        Debug.WriteLine(ex.ToString)
'    '        'Logger.LogError(LoggerLevel.Email, "DeCompressDataGZip", "", ex)
'    '    End Try
'    'End Function
'    Public Function DecompressData(ByVal TheData As Byte()) As Byte()
'        Dim FinData() As Byte
'        Try
'            Dim CT As CompressType
'            CT = TheData(TheData.Length - 1)
'            ReDim Preserve TheData(TheData.Length - 2)
'            If Not [Enum].IsDefined(GetType(CompressType), CT) Then
'                CT = CompressType.None
'            End If
'            Select Case CT
'                Case CompressType.NoCompression
'                    FinData = TheData

'                Case CompressType.CompressedZip
'                    FinData = DecompressDataZip(TheData)

'                Case CompressType.CompressedGZip
'                    FinData = DeCompressDataGZip(TheData)

'                Case Else
'                    FinData = TheData

'            End Select
'            Return FinData
'        Catch ex As Exception
'            'Logger.LogError(LoggerLevel.Email, "DecompressData", "", ex)
'        End Try
'        Return FinData
'    End Function
'    Public Function CompressData(ByVal TheData As Byte(), ByVal UseCompression As Boolean) As Byte()
'        Try
'            'Dim Msg As String
'            Dim FinData() As Byte
'            Dim CT As CompressType
'            If TheData.Length < 55 * 1024 Then
'                FinData = CompressDataZip(TheData)
'                ReDim Preserve FinData(FinData.Length)
'                CT = CompressType.CompressedZip
'                FinData(FinData.Length - 1) = CT
'            Else
'                FinData = CompressDataGZip(TheData)
'                ReDim Preserve FinData(FinData.Length)
'                CT = CompressType.CompressedGZip
'                FinData(FinData.Length - 1) = CT
'            End If

'            If FinData.Length > TheData.Length OrElse Not UseCompression Then
'                'Mark No Compression
'                ReDim Preserve TheData(TheData.Length)
'                CT = CompressType.NoCompression
'                TheData(TheData.Length - 1) = CT
'                'FinData = TheData
'                'Msg = "Not Compressed - Orig Size:" & TheData.Length & ", Compressed Size:" & FinData.Length
'                'Debug.WriteLine(Msg)
'                Return TheData
'            Else
'                'Mark Compression
'                'Msg = "Compressed - Orig Size:" & TheData.Length & ", Compressed Size:" & FinData.Length
'                'Debug.WriteLine(Msg)
'                Return FinData
'            End If

'        Catch ex As Exception
'            'Logger.LogError(LoggerLevel.Email, "CompressData", "", ex)
'        End Try
'    End Function
'    Private Function CompressDataGZip(ByVal TheData As Byte()) As Byte()
'        Try
'            Dim OutMemStream As New MemoryStream
'            Dim stmGzipArchive As Stream = New ICSharpCode.SharpZipLib.GZip.GZipOutputStream(OutMemStream)
'            stmGzipArchive.Write(TheData, 0, TheData.Length)
'            stmGzipArchive.Flush()
'            stmGzipArchive.Close()
'            Dim FinData() As Byte
'            FinData = OutMemStream.ToArray()
'            OutMemStream.Close()
'            Return FinData
'        Catch ex As Exception
'            'Logger.LogError(LoggerLevel.Email, "CompressDataGZip", "", ex)
'        End Try
'    End Function
'    Private Function DeCompressDataGZip(ByVal TheData As Byte()) As Byte()
'        Try
'            Dim FinData() As Byte
'            Dim nSize As Integer = 2048
'            Dim nSizeRead As Integer
'            Dim abyWriteData(2048) As Byte
'            Dim InMemStream As New MemoryStream
'            Dim OutMemStream As New MemoryStream
'            InMemStream.Write(TheData, 0, TheData.Length)
'            InMemStream.Flush()
'            InMemStream.Position = 0
'            Dim stmGzipArchive As Stream = New ICSharpCode.SharpZipLib.GZip.GZipInputStream(InMemStream)
'            While (True)
'                nSizeRead = stmGzipArchive.Read(abyWriteData, 0, nSize)
'                If nSizeRead > 0 Then
'                    OutMemStream.Write(abyWriteData, 0, nSizeRead)
'                Else
'                    Exit While
'                End If
'            End While
'            OutMemStream.Flush()
'            FinData = OutMemStream.ToArray()
'            OutMemStream.Close()
'            stmGzipArchive.Close()
'            Return FinData
'        Catch ex As Exception
'            'Logger.LogError(LoggerLevel.Email, "DeCompressDataGZip", "", ex)
'        End Try
'    End Function

'End Class


