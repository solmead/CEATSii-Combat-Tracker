'Public Class Handler
'    Public Shared Function LoadFromFile(ByVal FI As System.IO.FileInfo) As Object
'        Dim ms As System.IO.MemoryStream = New System.IO.MemoryStream
'        If FI.Exists Then
'            Dim fs As System.IO.FileStream = FI.OpenRead
'            Dim VD As Object
'            VD = UnPackData(fs)
'            fs.Close()
'            Return VD
'        Else
'            Return Nothing
'        End If
'    End Function
'    Public Shared Sub SaveToFile(ByVal TempV As Object, ByVal FI As System.IO.FileInfo)
'        Dim FS As System.IO.FileStream
'        Dim MS As System.IO.MemoryStream
'        Dim FI2 As New System.IO.FileInfo(FI.DirectoryName & "\Backup.ser")
'        If FI2.Exists Then FI2.Delete()
'        If FI.Exists Then FI.CopyTo(FI.DirectoryName & "\Backup.ser")
'        FI.Refresh()
'        If FI.Exists Then FI.Delete()
'        FI.Refresh()
'        If Not FI.Exists Then
'            FS = FI.OpenWrite
'            MS = PackData(TempV)
'            MS.Seek(0, IO.SeekOrigin.Begin)
'            MS.WriteTo(FS)
'            FS.Close()
'        End If
'    End Sub
'    'Public Shared Sub SaveToStream(ByVal V As Object, ByVal TheStream As System.IO.Stream)
'    '    Dim MS As System.IO.MemoryStream
'    '    MS = PackData(V)
'    '    TheStream.Write(MS.ToArray, 0, MS.Length)
'    'End Sub
'    'Public Shared Function LoadFromStream(ByVal TheStream As System.IO.Stream) As Object
'    '    Return UnPackData(TheStream)
'    'End Function
'    Public Shared Function PackData(ByVal V As Object, Optional ByVal Compressed As Boolean = True) As System.IO.MemoryStream
'        Dim ms As System.IO.MemoryStream = New System.IO.MemoryStream
'        Dim bf As New System.Runtime.Serialization.Formatters.Binary.BinaryFormatter
'        bf.Serialize(ms, V)
'        ms.Flush()
'        'If Compressed Then
'        Dim TBarr As Byte()
'        Dim Comp As New Compression
'        TBarr = Comp.CompressData(ms.ToArray, Compressed)
'        ms = New System.IO.MemoryStream
'        ms.Write(TBarr, 0, TBarr.Length)
'        'End If
'        Return ms
'        'Return ms.ToArray
'    End Function
'    Public Shared Function UnPackData(ByVal Data As Byte()) As Object
'        Dim ms As System.IO.MemoryStream = New System.IO.MemoryStream


'        Dim TBarr As Byte()
'        Dim Comp As New Compression
'        TBarr = Comp.DecompressData(Data)
'        ms.Write(TBarr, 0, TBarr.Length)
'        ms.Seek(0, IO.SeekOrigin.Begin)


'        Dim V As Object
'        Dim bf As New System.Runtime.Serialization.Formatters.Binary.BinaryFormatter
'        V = bf.Deserialize(ms)
'        Return V
'    End Function
'    Public Shared Function UnPackData(ByVal AStream As System.IO.Stream) As Object
'        AStream.Seek(0, IO.SeekOrigin.Begin)
'        Dim TBarr As Byte()
'        ReDim TBarr(AStream.Length - 1)
'        AStream.Read(TBarr, 0, AStream.Length)
'        Dim Comp As New Compression
'        TBarr = Comp.DecompressData(TBarr)
'        Dim MS As New System.IO.MemoryStream
'        MS.Write(TBarr, 0, TBarr.Length)
'        MS.Seek(0, IO.SeekOrigin.Begin)
'        Dim V As Object
'        Dim bf As New System.Runtime.Serialization.Formatters.Binary.BinaryFormatter
'        V = bf.Deserialize(MS)
'        Return V
'    End Function
'End Class

