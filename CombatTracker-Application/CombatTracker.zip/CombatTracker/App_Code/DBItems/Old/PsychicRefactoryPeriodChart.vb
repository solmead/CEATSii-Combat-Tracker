'Public Class PsychicRefactoryPeriodChartOld
'    Public Class RefactoryRound
'        Public Round As Integer
'        Public Modifier As Integer
'    End Class
'    Public Class RefactoryLevel
'        Public Min As Integer
'        Public Max As Integer
'        Public Mods As New Generic.List(Of RefactoryRound)
'        Public Function LookupNegative(ByVal RoundNumber As Integer) As Integer
'            Dim RM As RefactoryRound
'            For Each RM In Mods
'                If RM.Round = RoundNumber Then
'                    Return RM.Modifier
'                End If
'            Next
'            Dim lMod As Integer = Mods(Mods.Count - 1).Modifier
'            Dim Rnd As Integer = Mods(Mods.Count - 1).Round
'            While lMod < 0 AndAlso Rnd < RoundNumber
'                Rnd += 1
'                lMod += 5
'            End While
'            If lMod > 0 Then lMod = 0
'            Return lMod
'        End Function
'        Public Function RoundsToZero() As Integer
'            Dim lMod As Integer = Mods(Mods.Count - 1).Modifier
'            Dim Rnd As Integer = Mods(Mods.Count - 1).Round
'            While lMod < 0
'                Rnd += 1
'                lMod += 5
'            End While
'            Return Rnd
'        End Function
'    End Class
'    Public RefactoryLevels As New Generic.List(Of RefactoryLevel)
'    Public Shared Function Load(ByVal DataFile As Xml.XmlDocument) As PsychicRefactoryPeriodChartOld
'        Dim PRPC As New PsychicRefactoryPeriodChartOld
'        Dim XMl As Xml.XmlDocument
'        XMl = DataFile

'        If XMl Is Nothing Then
'            XMl = New Xml.XmlDocument
'            XMl.Load(My.Application.Info.DirectoryPath & "\datafile.xml")
'        End If
'        Dim XMLElem, Elem2, Elem3 As Xml.XmlElement
'        XMLElem = XMl.DocumentElement.SelectSingleNode("RefractoryPeriodModificationChart")
'        For Each Elem2 In XMLElem.ChildNodes
'            Dim RL As New RefactoryLevel
'            RL.Min = Elem2.GetAttribute("Min")
'            RL.Max = Elem2.GetAttribute("Max")
'            For Each Elem3 In Elem2.ChildNodes
'                Dim RR As New RefactoryRound
'                RR.Round = Val(Elem3.GetAttribute("Num"))
'                RR.Modifier = Val(Elem3.GetAttribute("Mod"))
'                RL.Mods.Add(RR)
'            Next
'            PRPC.RefactoryLevels.Add(RL)
'        Next
'        Return PRPC
'    End Function
'    Public Function LookupNegative(ByVal LevelDifferance As Integer, ByVal RoundNumber As Integer) As Integer
'        Dim RL As RefactoryLevel
'        For Each RL In RefactoryLevels
'            If RL.Min <= LevelDifferance AndAlso LevelDifferance <= RL.Max Then
'                Return RL.LookupNegative(RoundNumber)
'            End If
'        Next
'        Return 0
'    End Function
'    Public Function LookupRoundsToZero(ByVal LevelDifferance As Integer) As Integer
'        Dim RL As RefactoryLevel
'        For Each RL In RefactoryLevels
'            If RL.Min <= LevelDifferance AndAlso LevelDifferance <= RL.Max Then
'                Return RL.RoundsToZero
'            End If
'        Next
'        Return 0
'    End Function


'    Public Sub Delete()
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "Delete From PsychicRefractoryPeriodMod"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.ExecuteNonQuery()
'        'ID = 0
'        If Flagg Then DB.ConnEnd()
'    End Sub
'    Public Sub Save()
'        Dim DBEn As New DBEnabled
'        Dim Flagg As Boolean = DBEn.ConnStart()
'        Delete()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        Dim LD As RefactoryLevel
'        For Each LD In RefactoryLevels
'            Dim RM As RefactoryRound
'            For Each RM In LD.Mods
'                SQL = "Insert into PsychicRefractoryPeriodMod (RoundNumber,LevelMin,LevelMax,Mod) values (@RoundNumber,@LevelMin,@LevelMax,@Mod)"
'                Cmd = New SqlClient.SqlCommand(SQL, DBEn.MyConn)
'                Cmd.Parameters.Add(New SqlClient.SqlParameter("@RoundNumber", RM.Round))
'                Cmd.Parameters.Add(New SqlClient.SqlParameter("@LevelMin", LD.Min))
'                Cmd.Parameters.Add(New SqlClient.SqlParameter("@LevelMax", LD.Max))
'                Cmd.Parameters.Add(New SqlClient.SqlParameter("@Mod", RM.Modifier))
'                Cmd.ExecuteNonQuery()
'            Next
'        Next
'        If Flagg Then DBEn.ConnEnd()
'    End Sub
'    Public Shared Function Load() As PsychicRefactoryPeriodChartOld
'        Dim LevChart As New PsychicRefactoryPeriodChartOld
'        Dim DBEn As New DBEnabled
'        Dim Flagg As Boolean = DBEn.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "Select RoundNumber,LevelMin,LevelMax,Mod from PsychicRefractoryPeriodMod order by LevelMin,RoundNumber"
'        Cmd = New SqlClient.SqlCommand(SQL, DBEn.MyConn)
'        Dim Dt As New DataTable
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        DA.Fill(Dt)
'        Dim DR As DataRow
'        Dim LD As New RefactoryLevel
'        If Dt.Rows.Count > 0 Then
'            LD.Min = Dt.Rows(0)("LevelMin")
'            LD.Max = Dt.Rows(0)("LevelMax")
'        End If
'        For Each DR In Dt.Rows
'            Dim LC As Integer = DR("LevelMin")
'            If LC <> LD.Min Then
'                LevChart.RefactoryLevels.Add(LD)
'                LD = New RefactoryLevel
'                LD.Min = DR("LevelMin")
'                LD.Max = DR("LevelMax")
'            End If
'            Dim RM As New RefactoryRound
'            RM.Round = DR("RoundNumber")
'            RM.Modifier = DR("Mod")
'            LD.Mods.Add(RM)
'        Next
'        LevChart.RefactoryLevels.Add(LD)
'        Return LevChart
'    End Function
'End Class
