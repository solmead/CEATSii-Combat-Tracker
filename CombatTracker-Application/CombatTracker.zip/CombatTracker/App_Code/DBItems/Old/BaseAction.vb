'Public Class BaseActionOld

'    Private m_ID As Integer
'    Private m_Group As ActionGroupOld
'    Private m_ActionGroup_ID As Integer
'    Private m_Name As String = "Unknown"
'    Private m_BasePercent As Double = 0.0001
'    Private m_IsAttack As Boolean = False
'    Private m_IsSpell As Boolean = False
'    Private m_NextAction_ID As Integer
'    Private m_NextActionName As String = ""
'    Private m_Nextaction As BaseActionOld = Nothing
'    Public Property ID() As Integer
'        Get
'            Return m_ID
'        End Get
'        Set(ByVal Value As Integer)
'            m_ID = Value
'        End Set
'    End Property

'    Public Property Group() As ActionGroupOld
'        Get
'            If m_Group Is Nothing Then
'                m_Group = ActionGroupOld.Load(ActionGroup_ID)
'            End If
'            Return m_Group
'        End Get
'        Set(ByVal Value As ActionGroupOld)
'            m_Group = Value
'            ActionGroup_ID = Value.ID
'        End Set
'    End Property

'    Public Property ActionGroup_ID() As Integer
'        Get
'            Return m_ActionGroup_ID
'        End Get
'        Set(ByVal Value As Integer)
'            m_ActionGroup_ID = Value
'        End Set
'    End Property

'    Public Property Name() As String
'        Get
'            Return m_Name
'        End Get
'        Set(ByVal Value As String)
'            m_Name = Value
'        End Set
'    End Property

'    Public Property BasePercent() As Double
'        Get
'            Return m_BasePercent
'        End Get
'        Set(ByVal Value As Double)
'            m_BasePercent = Value
'        End Set
'    End Property

'    Public Property IsAttack() As Boolean
'        Get
'            Return m_IsAttack
'        End Get
'        Set(ByVal Value As Boolean)
'            m_IsAttack = Value
'        End Set
'    End Property

'    Public Property IsSpell() As Boolean
'        Get
'            Return m_IsSpell
'        End Get
'        Set(ByVal Value As Boolean)
'            m_IsSpell = Value
'        End Set
'    End Property

'    Public Property NextAction_ID() As Integer
'        Get
'            Return m_NextAction_ID
'        End Get
'        Set(ByVal Value As Integer)
'            m_NextAction_ID = Value
'        End Set
'    End Property

'    Public Property NextActionName() As String
'        Get
'            Return m_NextActionName
'        End Get
'        Set(ByVal Value As String)
'            m_NextActionName = Value
'        End Set
'    End Property

'    Public Property Nextaction() As BaseActionOld
'        Get
'            If m_Nextaction Is Nothing AndAlso NextAction_ID <> 0 Then
'                m_Nextaction = BaseActionOld.Load(NextAction_ID)
'                NextActionName = m_Nextaction.Name
'            End If
'            Return m_Nextaction
'        End Get
'        Set(ByVal Value As BaseActionOld)
'            m_Nextaction = Value
'            NextAction_ID = Value.ID
'            NextActionName = Value.Name
'        End Set
'    End Property


'    Public Overrides Function ToString() As String
'        Return Name
'    End Function
'    Public Function GetStandardAction() As StandardAction
'        Dim SA As New StandardAction
'        SA.Name = Name
'        SA.BasePercent = BasePercent
'        'SA.Base = Me
'        SA.IsAttack = IsAttack
'        SA.IsSpell = IsSpell
'        Return SA
'    End Function
'    Public Sub Delete()
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "Delete From Actions where ID=@ID"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'        Cmd.ExecuteNonQuery()
'        ID = 0
'        If Flagg Then DB.ConnEnd()
'    End Sub
'    Public Sub Save()
'        Dim DBEn As New DBEnabled
'        Dim Flagg As Boolean = DBEn.ConnStart()

'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        If ID = 0 Then
'            SQL = "Insert into Actions (ActionGroup_ID, Name, BasePercent, IsAttack, IsSpell, NextAction_ID) values (@ActionGroup_ID, @Name, @BasePercent, @IsAttack, @IsSpell, @NextAction_ID); Select @@Identity"
'        Else
'            SQL = "Update Actions Set ActionGroup_ID=@ActionGroup_ID, Name=@Name, BasePercent=@BasePercent, IsAttack=@IsAttack, IsSpell=@IsSpell, NextAction_ID=@NextAction_ID Where ID=@ID"
'        End If
'        Cmd = New SqlClient.SqlCommand(SQL, DBEn.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Name", Name))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@ActionGroup_ID", Group.ID))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@BasePercent", BasePercent))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@IsAttack", IsAttack))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@IsSpell", IsSpell))
'        If Nextaction Is Nothing Then
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@NextAction_ID", 0))
'        Else
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@NextAction_ID", Nextaction.ID))
'        End If
'        If ID = 0 Then
'            ID = Cmd.ExecuteScalar
'        Else
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'            Cmd.ExecuteNonQuery()
'        End If
'        If Nextaction IsNot Nothing AndAlso Nextaction.ID = 0 Then
'            Nextaction.Save()
'            Me.Save()
'        End If
'        If Flagg Then DBEn.ConnEnd()
'    End Sub

'    Private Sub Load(ByVal DR As DataRow)
'        'ActionGroup_ID, Name, BasePercent, IsAttack, IsSpell, NextAction_ID
'        ID = CInt(GetData(DR, "ID"))
'        Name = GetData(DR, "Name")
'        ActionGroup_ID = CInt(GetData(DR, "ActionGroup_ID"))
'        BasePercent = CDbl(GetData(DR, "BasePercent"))
'        IsAttack = CBool(GetData(DR, "IsAttack"))
'        IsSpell = CBool(GetData(DR, "IsSpell"))
'        NextAction_ID = CInt(GetData(DR, "NextAction_ID"))
'    End Sub
'    Public Shared Function Load(ByVal ID As Integer) As BaseActionOld
'        Dim DB As New DBEnabled
'        Dim CI As New BaseActionOld
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,ActionGroup_ID, Name, BasePercent, IsAttack, IsSpell, NextAction_ID FROM Actions where ID=@ID"

'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        If DT.Rows.Count > 0 Then
'            DR = DT.Rows(0)
'            CI.Load(DR)
'        End If
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return CI
'    End Function
'    Public Shared Function Find(ByVal Name As String) As BaseActionOld
'        Dim DB As New DBEnabled
'        Dim CI As New BaseActionOld
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,ActionGroup_ID, Name, BasePercent, IsAttack, IsSpell, NextAction_ID FROM Actions where Name=@Name"

'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Name", Name))
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        If DT.Rows.Count > 0 Then
'            DR = DT.Rows(0)
'            CI.Load(DR)
'        End If
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return CI
'    End Function
'    Public Shared Function GetActionsForActionGroup(ByVal TheGroup As ActionGroupOld) As Generic.List(Of BaseActionOld)
'        Dim List As New Generic.List(Of BaseActionOld)
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,ActionGroup_ID, Name, BasePercent, IsAttack, IsSpell, NextAction_ID FROM Actions where ActionGroup_ID=@ActionGroup_ID"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@ActionGroup_ID", TheGroup.ID))
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        For Each DR In DT.Rows
'            Dim CI As New BaseActionOld
'            CI.Load(DR)
'            CI.Group = TheGroup
'            List.Add(CI)
'        Next
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return List
'    End Function
'    Public Shared Function GetActions() As Generic.List(Of BaseActionOld)
'        Dim List As New Generic.List(Of BaseActionOld)
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,ActionGroup_ID, Name, BasePercent, IsAttack, IsSpell, NextAction_ID FROM Actions"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        For Each DR In DT.Rows
'            Dim CI As New BaseActionOld
'            CI.Load(DR)
'            List.Add(CI)
'        Next
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return List
'    End Function
'End Class
