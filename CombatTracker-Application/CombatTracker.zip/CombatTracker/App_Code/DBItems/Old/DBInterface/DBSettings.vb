'Public Class SettingsPair
'    Public Name As String = ""
'    Public Value As String = ""
'    Public Sub New()

'    End Sub
'    Public Sub New(ByVal Name As String, ByVal Value As String)
'        Me.Name = Name
'        Me.Value = Value
'    End Sub
'End Class

'Public Class DBSettings
'    Inherits DBEnabled
'    Public Sub New()
'        CheckDB()
'    End Sub
'    Private Sub CheckDB()
'        If CheckedDB Then Exit Sub
'        CheckedDB = True
'        Dim Flagg As Boolean = ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT top 1 ID FROM Settings"
'        Cmd = New SqlClient.SqlCommand(SQL, MyConn)
'        Try
'            Cmd.ExecuteScalar()
'        Catch ex As Exception
'            SQL = "CREATE TABLE [dbo].[Settings]( [ID] [int] IDENTITY(1,1) NOT NULL, [Name] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, [Value] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]"
'            Cmd = New SqlClient.SqlCommand(SQL, MyConn)
'            Cmd.ExecuteNonQuery()
'        End Try

'        WriteToConfig("Settings_Version", System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString)
'        If Flagg Then ConnEnd()
'    End Sub
'    Public Shared Function GetValue(ByVal Name As String, Optional ByVal [Default] As String = "") As String
'        Dim DBS As New DBSettings
'        Return DBS.GetfromConfig(Name, [Default])
'    End Function

'    Public Shared WriteOnly Property SetValue(ByVal Name As String) As String
'        Set(ByVal value As String)
'            Dim DBS As New DBSettings
'            DBS.WriteToConfig(Name, value)
'        End Set
'    End Property
'    Public Shared Function GetConfigSetting(ByVal Name As String) As String
'        Dim CS As String = ""
'        Try
'            CS = System.Web.Configuration.WebConfigurationManager.AppSettings(Name)
'        Catch ex As Exception

'        End Try
'        Try
'            If CS = "" Then
'                System.Configuration.ConfigurationSettings.AppSettings.Get(Name)
'            End If
'        Catch ex As Exception

'        End Try
'        Return CS
'    End Function


'    Public Sub WriteToConfig(ByVal Name As String, ByVal Value As String)
'        Dim Flagg As Boolean = Me.ConnStart

'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        Dim Tstr As String
'        SQL = "Select Value from Settings where Name=@Name"
'        Cmd = New SqlClient.SqlCommand(SQL, MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Name", Name))
'        Tstr = Cmd.ExecuteScalar
'        If Tstr Is Nothing Then
'            SQL = "Insert into Settings (Name,Value) values (@Name,@Value)"
'            Cmd = New SqlClient.SqlCommand(SQL, MyConn)
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@Name", Name))
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@Value", Value))
'            Cmd.ExecuteNonQuery()
'            Tstr = ""
'        Else
'            SQL = "Update Settings Set Value=@Value where Name=@Name"
'            Cmd = New SqlClient.SqlCommand(SQL, MyConn)
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@Value", Value))
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@Name", Name))
'            Cmd.ExecuteNonQuery()
'        End If

'        If Flagg Then Me.ConnEnd()
'    End Sub
'    Public Function GetfromConfig(ByVal Name As String, Optional ByVal [Default] As String = "") As String
'        Dim Tstr As String
'        Dim Flagg As Boolean = Me.ConnStart
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "Select Value from Settings where Name=@Name"
'        Cmd = New SqlClient.SqlCommand(SQL, MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Name", Name))
'        Tstr = Cmd.ExecuteScalar
'        If Tstr Is Nothing Then
'            SQL = "Insert into Settings (Name,Value) values (@Name,@Value)"
'            Cmd = New SqlClient.SqlCommand(SQL, MyConn)
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@Name", Name))
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@Value", [Default]))
'            Cmd.ExecuteNonQuery()
'            Tstr = [Default]
'        End If
'        If Flagg Then Me.ConnEnd()
'        Return Tstr
'    End Function
'    Public Function GetSettings() As Generic.List(Of SettingsPair)
'        Dim mList As New Generic.List(Of SettingsPair)
'        Dim Flagg As Boolean = Me.ConnStart
'        Dim SQL As String
'        Dim DA As SqlClient.SqlDataAdapter
'        Dim DT As DataTable
'        Dim DR As DataRow
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "Select Name,Value from Settings"
'        Cmd = New SqlClient.SqlCommand(SQL, MyConn)
'        DA = New SqlClient.SqlDataAdapter(Cmd)
'        DT = New DataTable
'        DA.Fill(DT)
'        For Each DR In DT.Rows
'            mList.Add(New SettingsPair(DR("Name"), DR("Value")))
'        Next
'        If Flagg Then Me.ConnEnd()
'        Return mList
'    End Function
'End Class
