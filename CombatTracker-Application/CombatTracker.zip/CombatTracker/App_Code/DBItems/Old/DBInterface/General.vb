'Imports Microsoft.VisualBasic

'Public Module General

'    Public IISort As String = ""
'    Public CheckedDB As Boolean = False
'    Public Function GetData(ByVal Row As System.Data.DataRow, ByVal Name As String, Optional ByVal [Default] As String = "") As String
'        If Row.IsNull(Name) Then
'            Return [Default]
'        Else
'            Return Row(Name)
'        End If
'    End Function
'    Public Function GetDateData(ByVal Row As System.Data.DataRow, ByVal Name As String, Optional ByVal [Default] As Date = Nothing) As Date
'        If Row.IsNull(Name) Then
'            Return [Default]
'        Else
'            Dim tstr As String = Row(Name)
'            If IsDate(tstr) Then
'                Return CDate(tstr)
'            Else
'                Return [Default]
'            End If
'        End If
'    End Function
'    Public Function HandleNull(ByVal Value As String) As Object
'        If Value Is Nothing Then
'            Return System.DBNull.Value
'        Else
'            Return Value
'        End If
'    End Function
'    Public Function HandleNull(ByVal Value As Date) As Object
'        Dim C As Date = Nothing
'        If Value = C Then
'            Return System.DBNull.Value
'        Else
'            Return Value
'        End If
'    End Function
'    Public Function GetDate(ByVal Value As Date) As String
'        Dim D As Date = Nothing
'        If D = Value Then
'            Return ""
'        Else
'            Return Value.ToShortDateString
'        End If
'    End Function
'    Public Function GetDate(ByVal Value As String) As Date
'        If Value = "" Then
'            Return Nothing
'        Else
'            Try
'                Return CDate(Value)
'            Catch ex As Exception
'                Return Nothing
'            End Try
'        End If
'    End Function
'    Public Sub WriteDebug(ByVal Text As String)
'        System.Diagnostics.Debug.WriteLine(Now & " " & Text)
'    End Sub

'End Module
