'Imports System.Data

'Public Class DBEnabled
'    Public MyConn As SqlClient.SqlConnection
'    Private Function GetNamedConnStr(ByVal ConnName As String) As String
'        Dim CS As String = ""
'        Try
'            If System.Web.Configuration.WebConfigurationManager.ConnectionStrings(ConnName) IsNot Nothing Then
'                CS = System.Web.Configuration.WebConfigurationManager.ConnectionStrings(ConnName).ConnectionString
'            End If
'        Catch ex As Exception
'            Debug.WriteLine("Ignore")
'        End Try
'        Try
'            If CS = "" Then
'                CS = System.Configuration.ConfigurationSettings.AppSettings.Get(ConnName)
'            End If
'        Catch ex As Exception

'        End Try
'        Return CS
'    End Function
'    Public Function GetConnString() As String
'        Dim LiveConnStr As String = ""
'        Dim DevConnStr As String = ""

'        LiveConnStr = GetNamedConnStr("CMS_ConnectionString")
'        DevConnStr = GetNamedConnStr("CMS_ConnectionString_Dev")
'        If LiveConnStr = "" Then
'            If DevConnStr = "" Then
'                Return ""
'            Else
'                Return DevConnStr
'            End If
'        ElseIf DevConnStr = "" Then 'LiveConnStr contains something
'            Return LiveConnStr
'        Else 'Both contain something
'            If DBSettings.GetConfigSetting("DBtoUse") = "Live" Then
'                Return LiveConnStr
'            ElseIf DBSettings.GetConfigSetting("DBtoUse") = "Dev" Then
'                Return DevConnStr
'            Else
'                Dim URL As String = System.Web.HttpContext.Current.Request.Url.Host
'                If InStr(URL.ToUpper, "LOCALHOST") > 0 OrElse InStr(URL.ToUpper, "DEV.ISOC.NET") > 0 Then
'                    Return DevConnStr
'                Else
'                    Return LiveConnStr
'                End If
'            End If
'        End If

'        Return ""
'    End Function
'    Public Function ConnStart() As Boolean
'        Dim Flagg As Boolean = False
'        If MyConn Is Nothing Then
'            Flagg = True
'            MyConn = New SqlClient.SqlConnection(GetConnString)
'            MyConn.Open()
'        End If
'        Return Flagg
'    End Function
'    Public Sub ConnEnd()
'        MyConn.Close()
'        MyConn = Nothing
'    End Sub
'End Class