
'<Serializable()> Public Class AttackOld
'    Implements System.Runtime.Serialization.ISerializable

'    Private m_ID As Integer
'    Private m_PercentChance As Double = 100
'    Private m_OB As Integer = 0
'    Private m_MaxOB As Integer = 0
'    Private m_Type As AttackType = AttackType.Bash
'    Private m_WeaponUsed As WeaponOld = Nothing
'    Private WeaponUsed_ID As Integer
'    Private m_Size As SizeRating = SizeRating.Medium
'    Private m_ThisRoundSuccess As AttackOld = Nothing
'    Private ThisRoundSuccess_ID As Integer
'    Private m_NextRoundSuccess As AttackOld = Nothing
'    Private NextRoundSuccess_ID As Integer
'    Private m_Number As Integer = 1
'    Private m_DamageMultiplier As Integer = 1
'    Private m_AdditionalCrits As List(Of CritTypes)
'    Private m_CriticalLevel As CriticalLevels = CriticalLevels.Same
'    Private m_AdditionalCritsIsOr As Boolean = False
'    Private m_UseCriticalInstead As CritTypes = CritTypes.None
'    Private m_ParentAttack As AttackOld
'    Private ParentAttack_ID As Integer
'    Private m_Creature_On As CreatureOld
'    Private CreatureOn_ID As Integer
'    '
'    Public Property ID() As Integer
'        Get
'            Return m_ID
'        End Get
'        Set(ByVal Value As Integer)
'            m_ID = Value
'        End Set
'    End Property

'    Public Property PercentChance() As Double
'        Get
'            Return m_PercentChance
'        End Get
'        Set(ByVal Value As Double)
'            m_PercentChance = Value
'        End Set
'    End Property

'    Public Property OB() As Integer
'        Get
'            Return m_OB
'        End Get
'        Set(ByVal Value As Integer)
'            m_OB = Value
'        End Set
'    End Property

'    Public Property MaxOB() As Integer
'        Get
'            Return m_MaxOB
'        End Get
'        Set(ByVal Value As Integer)
'            m_MaxOB = Value
'        End Set
'    End Property

'    Public Property Type() As AttackType
'        Get
'            Return m_Type
'        End Get
'        Set(ByVal Value As AttackType)
'            m_Type = Value
'        End Set
'    End Property

'    Public Property WeaponUsed() As WeaponOld
'        Get
'            If m_WeaponUsed Is Nothing AndAlso WeaponUsed_ID <> 0 Then
'                m_WeaponUsed = WeaponOld.Load(WeaponUsed_ID)
'            End If
'            Return m_WeaponUsed
'        End Get
'        Set(ByVal Value As WeaponOld)
'            m_WeaponUsed = Value
'        End Set
'    End Property

'    Public Property Size() As SizeRating
'        Get
'            Return m_Size
'        End Get
'        Set(ByVal Value As SizeRating)
'            m_Size = Value
'        End Set
'    End Property

'    Public Property ThisRoundSuccess() As AttackOld
'        Get
'            If m_ThisRoundSuccess Is Nothing AndAlso ThisRoundSuccess_ID <> 0 Then
'                m_ThisRoundSuccess = AttackOld.Load(ThisRoundSuccess_ID)
'            End If
'            Return m_ThisRoundSuccess
'        End Get
'        Set(ByVal Value As AttackOld)
'            m_ThisRoundSuccess = Value
'        End Set
'    End Property

'    Public Property NextRoundSuccess() As AttackOld
'        Get
'            If m_NextRoundSuccess Is Nothing AndAlso NextRoundSuccess_ID <> 0 Then
'                m_NextRoundSuccess = AttackOld.Load(NextRoundSuccess_ID)
'            End If
'            Return m_NextRoundSuccess
'        End Get
'        Set(ByVal Value As AttackOld)
'            m_NextRoundSuccess = Value
'        End Set
'    End Property

'    Public Property Number() As Integer
'        Get
'            Return m_Number
'        End Get
'        Set(ByVal Value As Integer)
'            m_Number = Value
'        End Set
'    End Property

'    Public Property DamageMultiplier() As Integer
'        Get
'            Return m_DamageMultiplier
'        End Get
'        Set(ByVal Value As Integer)
'            m_DamageMultiplier = Value
'        End Set
'    End Property

'    Public Property AdditionalCrits() As List(Of CritTypes)
'        Get
'            If m_AdditionalCrits Is Nothing Then
'                LoadAdditionalcrits()
'            End If
'            Return m_AdditionalCrits
'        End Get
'        Set(ByVal Value As List(Of CritTypes))
'            m_AdditionalCrits = Value
'        End Set
'    End Property

'    Public Property CriticalLevel() As CriticalLevels
'        Get
'            Return m_CriticalLevel
'        End Get
'        Set(ByVal Value As CriticalLevels)
'            m_CriticalLevel = Value
'        End Set
'    End Property

'    Public Property AdditionalCritsIsOr() As Boolean
'        Get
'            Return m_AdditionalCritsIsOr
'        End Get
'        Set(ByVal Value As Boolean)
'            m_AdditionalCritsIsOr = Value
'        End Set
'    End Property

'    Public Property UseCriticalInstead() As CritTypes
'        Get
'            Return m_UseCriticalInstead
'        End Get
'        Set(ByVal Value As CritTypes)
'            m_UseCriticalInstead = Value
'        End Set
'    End Property

'    Public Property ParentAttack2() As AttackOld
'        Get
'            If m_ParentAttack Is Nothing AndAlso ParentAttack_ID <> 0 Then
'                m_ParentAttack = AttackOld.Load(ParentAttack_ID)
'            End If
'            Return m_ParentAttack
'        End Get
'        Set(ByVal Value As AttackOld)
'            m_ParentAttack = Value
'        End Set
'    End Property

'    Public Property Creature_On() As CreatureOld
'        Get
'            If m_Creature_On Is Nothing AndAlso CreatureOn_ID <> 0 Then
'                m_Creature_On = CreatureOld.Load(CreatureOn_ID)
'            End If
'            Return m_Creature_On
'        End Get
'        Set(ByVal Value As CreatureOld)
'            m_Creature_On = Value
'        End Set
'    End Property

'    Public Sub New(ByVal info As System.Runtime.Serialization.SerializationInfo, ByVal context As System.Runtime.Serialization.StreamingContext)
'        PercentChance = info.GetDouble("PercentChance")
'        OB = info.GetInt32("OB")
'        MaxOB = info.GetInt32("MaxOB")
'        Size = info.GetInt32("Size")
'        Type = info.GetInt32("Type")
'        WeaponUsed = info.GetValue("WeaponUsed", GetType(WeaponOld))
'        Size = info.GetInt32("Size")
'        ThisRoundSuccess = info.GetValue("ThisRoundSuccess", GetType(AttackOld))
'        NextRoundSuccess = info.GetValue("NextRoundSuccess", GetType(AttackOld))
'        Number = info.GetInt32("Number")
'        DamageMultiplier = info.GetInt32("DamageMultiplier")
'        AdditionalCrits = info.GetValue("AdditionalCrits", GetType(List(Of CritTypes)))
'        CriticalLevel = info.GetInt32("CriticalLevel")
'        AdditionalCritsIsOr = info.GetBoolean("AdditionalCritsIsOr")
'        UseCriticalInstead = info.GetInt32("UseCriticalInstead")
'        ParentAttack2 = info.GetValue("ParentAttack", GetType(AttackOld))

'    End Sub

'    Public Function Clone(Optional ByVal Parent As AttackOld = Nothing) As AttackOld
'        Dim atk As New AttackOld
'        atk.PercentChance = Me.PercentChance
'        atk.OB = Me.OB
'        atk.MaxOB = Me.MaxOB
'        atk.Type = Me.Type
'        atk.WeaponUsed = Me.WeaponUsed
'        atk.Size = Me.Size
'        If Me.ThisRoundSuccess IsNot Nothing Then
'            atk.ThisRoundSuccess = Me.ThisRoundSuccess.Clone(atk)
'        End If
'        If Me.NextRoundSuccess IsNot Nothing Then
'            atk.NextRoundSuccess = Me.NextRoundSuccess.Clone(atk)
'        End If
'        atk.Number = Me.Number
'        atk.DamageMultiplier = Me.DamageMultiplier
'        atk.AdditionalCrits = Me.AdditionalCrits
'        atk.AdditionalCritsIsOr = Me.AdditionalCritsIsOr
'        atk.UseCriticalInstead = Me.UseCriticalInstead
'        atk.ParentAttack2 = Parent
'        atk.CriticalLevel = Me.CriticalLevel
'        Return atk
'    End Function
'    Public Sub ModifyOB(ByVal LevelDiff As Integer)
'        OB = OB + LevelDiff * 5
'        If Me.ThisRoundSuccess IsNot Nothing Then
'            Me.ThisRoundSuccess.ModifyOB(LevelDiff)
'        End If
'        If Me.NextRoundSuccess IsNot Nothing Then
'            Me.NextRoundSuccess.ModifyOB(LevelDiff)
'        End If
'    End Sub
'    Public Sub New()

'    End Sub
'    'Public Sub New(ByVal Parent As Attack)
'    '    ParentAttack = Parent
'    'End Sub
'    Public Overrides Function ToString() As String
'        Dim Ast As String
'        If Type = AttackType.Weapon Then
'            Ast = OB & " " & WeaponUsed.Name
'        Else
'            Ast = OB & " " & Size.ToString & " " & Type.ToString
'        End If
'        Return Ast
'    End Function

'    Public Sub GetObjectData(ByVal info As System.Runtime.Serialization.SerializationInfo, ByVal context As System.Runtime.Serialization.StreamingContext) Implements System.Runtime.Serialization.ISerializable.GetObjectData

'    End Sub
'    Private Sub LoadAdditionalcrits()
'        m_AdditionalCrits = New List(Of CritTypes)
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "Select Critical from AttacksAddCrits where AttackID=@Attack_ID"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Attack_ID", ID))
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        For Each DR In DT.Rows
'            m_AdditionalCrits.Add([Enum].Parse(GetType(CritTypes), DR("Critical")))
'        Next
'    End Sub
'    Public Sub Delete()
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "Delete From Attacks where ID=@ID"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'        Cmd.ExecuteNonQuery()
'        If ThisRoundSuccess IsNot Nothing Then ThisRoundSuccess.Delete()
'        If NextRoundSuccess IsNot Nothing Then NextRoundSuccess.Delete()
'        If WeaponUsed IsNot Nothing Then WeaponUsed.Delete()
'        SQL = "Delete from AttacksAddCrits where AttackID=@Attack_ID"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Attack_ID", ID))
'        Cmd.ExecuteNonQuery()
'        ID = 0
'        If Flagg Then DB.ConnEnd()
'    End Sub
'    Public Sub Save()
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        If m_WeaponUsed IsNot Nothing Then
'            WeaponUsed.Save()
'        End If
'        If m_ThisRoundSuccess IsNot Nothing Then
'            ThisRoundSuccess.Save()
'        End If
'        If m_NextRoundSuccess IsNot Nothing Then
'            NextRoundSuccess.Save()
'        End If
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        If ID = 0 Then
'            SQL = "Insert into Attacks (PercentChance, OB, MaxOB, Type, WeaponUsed_ID,Size,ThisRoundSuccess_ID,NextRoundSuccess_ID,Number,DamageMultiplier,CriticalLevel,AdditionalCritsIsOr,UseCriticalInstead,ParentAttack_ID,CreatureOn_ID) values (@PercentChance, @OB, @MaxOB, @Type, @WeaponUsed_ID,@Size,@ThisRoundSuccess_ID,@NextRoundSuccess_ID,@Number,@DamageMultiplier,@CriticalLevel,@AdditionalCritsIsOr,@UseCriticalInstead,@ParentAttack_ID,@CreatureOn_ID); Select @@Identity"
'        Else
'            SQL = "Update Attacks Set PercentChance=@PercentChance, OB=@OB, MaxOB=@MaxOB, Type=@Type, WeaponUsed_ID=@WeaponUsed_ID,Size=@Size,ThisRoundSuccess_ID=@ThisRoundSuccess_ID,NextRoundSuccess_ID=@NextRoundSuccess_ID,Number=@Number,DamageMultiplier=@DamageMultiplier,CriticalLevel=@CriticalLevel,AdditionalCritsIsOr=@AdditionalCritsIsOr,UseCriticalInstead=@UseCriticalInstead,ParentAttack_ID=@ParentAttack_ID,CreatureOn_ID=@CreatureOn_ID Where ID=@ID"
'        End If
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@PercentChance", PercentChance))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@OB", OB))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@MaxOB", MaxOB))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Type", Type.ToString))
'        If m_WeaponUsed Is Nothing Then
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@WeaponUsed_ID", WeaponUsed_ID))
'        Else
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@WeaponUsed_ID", WeaponUsed.ID))
'        End If
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Size", Size.ToString))
'        If m_ThisRoundSuccess Is Nothing Then
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@ThisRoundSuccess_ID", ThisRoundSuccess_ID))
'        Else
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@ThisRoundSuccess_ID", ThisRoundSuccess.ID))
'        End If
'        If m_NextRoundSuccess Is Nothing Then
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@NextRoundSuccess_ID", NextRoundSuccess_ID))
'        Else
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@NextRoundSuccess_ID", NextRoundSuccess.ID))
'        End If
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Number", Number))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@DamageMultiplier", DamageMultiplier))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@CriticalLevel", CriticalLevel.ToString))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@AdditionalCritsIsOr", AdditionalCritsIsOr))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@UseCriticalInstead", UseCriticalInstead.ToString))
'        If m_ParentAttack Is Nothing Then
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@ParentAttack_ID", ParentAttack_ID))
'        Else
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@ParentAttack_ID", ParentAttack2.ID))
'        End If
'        If m_Creature_On Is Nothing Then
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@CreatureOn_ID", CreatureOn_ID))
'        Else
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@CreatureOn_ID", Creature_On.ID))
'        End If



'        If ID = 0 Then
'            ID = Cmd.ExecuteScalar
'        Else
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'            Cmd.ExecuteNonQuery()
'        End If
'        If m_AdditionalCrits IsNot Nothing Then
'            SQL = "Delete from AttacksAddCrits where AttackID=@Attack_ID"
'            Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@Attack_ID", ID))
'            Cmd.ExecuteNonQuery()
'            Dim Crit As CritTypes
'            For Each Crit In AdditionalCrits
'                SQL = "Insert into AttacksAddCrits (AttackID,Critical) values (@Attack_ID,@Critical)"
'                Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'                Cmd.Parameters.Add(New SqlClient.SqlParameter("@Attack_ID", ID))
'                Cmd.Parameters.Add(New SqlClient.SqlParameter("@Critical", Crit.ToString))
'                Cmd.ExecuteNonQuery()
'            Next
'        End If
'        If m_ThisRoundSuccess IsNot Nothing Then
'            ThisRoundSuccess.ParentAttack2 = Me
'            ThisRoundSuccess.Save()
'        End If
'        If m_NextRoundSuccess IsNot Nothing Then
'            NextRoundSuccess.ParentAttack2 = Me
'            NextRoundSuccess.Save()
'        End If

'        If Flagg Then DB.ConnEnd()
'    End Sub

'    Private Sub Load(ByVal DR As DataRow)
'        'PercentChance, OB, MaxOB, Type, WeaponUsed_ID,Size,ThisRoundSuccess_ID,NextRoundSuccess_ID,Number,DamageMultiplier,CriticalLevel,AdditionalCritsIsOr,UseCriticalInstead,ParentAttack_ID,CreatureOn_ID
'        ID = CInt(GetData(DR, "ID"))
'        PercentChance = CDbl(GetData(DR, "PercentChance"))
'        OB = CInt(GetData(DR, "OB"))
'        MaxOB = CInt(GetData(DR, "MaxOB"))
'        Type = [Enum].Parse(GetType(AttackType), GetData(DR, "Type"))
'        WeaponUsed_ID = CInt(GetData(DR, "WeaponUsed_ID"))
'        Size = [Enum].Parse(GetType(SizeRating), GetData(DR, "Size"))
'        ThisRoundSuccess_ID = CInt(GetData(DR, "ThisRoundSuccess_ID"))
'        NextRoundSuccess_ID = CInt(GetData(DR, "NextRoundSuccess_ID"))
'        Number = CInt(GetData(DR, "Number"))
'        DamageMultiplier = CInt(GetData(DR, "DamageMultiplier"))
'        CriticalLevel = [Enum].Parse(GetType(CriticalLevels), GetData(DR, "CriticalLevel"))
'        AdditionalCritsIsOr = CBool(GetData(DR, "AdditionalCritsIsOr"))
'        UseCriticalInstead = [Enum].Parse(GetType(CritTypes), GetData(DR, "UseCriticalInstead"))
'        ParentAttack_ID = CInt(GetData(DR, "ParentAttack_ID"))
'        CreatureOn_ID = CInt(GetData(DR, "CreatureOn_ID"))
'    End Sub
'    Public Shared Function Load(ByVal ID As Integer) As AttackOld
'        Dim DB As New DBEnabled
'        Dim CI As New AttackOld
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,PercentChance, OB, MaxOB, Type, WeaponUsed_ID,Size,ThisRoundSuccess_ID,NextRoundSuccess_ID,Number,DamageMultiplier,CriticalLevel,AdditionalCritsIsOr,UseCriticalInstead,ParentAttack_ID,CreatureOn_ID FROM Attacks where ID=@ID"

'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        If DT.Rows.Count > 0 Then
'            DR = DT.Rows(0)
'            CI.Load(DR)
'        End If
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return CI
'    End Function
'    Public Shared Function GetAttacksOnCreature(ByVal TheCreature As CreatureOld) As Generic.List(Of AttackOld)
'        Dim List As New Generic.List(Of AttackOld)
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,PercentChance, OB, MaxOB, Type, WeaponUsed_ID,Size,ThisRoundSuccess_ID,NextRoundSuccess_ID,Number,DamageMultiplier,CriticalLevel,AdditionalCritsIsOr,UseCriticalInstead,ParentAttack_ID,CreatureOn_ID FROM Attacks where CreatureOn_ID=@CreatureOn_ID"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@CreatureOn_ID", TheCreature.ID))
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        For Each DR In DT.Rows
'            Dim CI As New AttackOld
'            CI.Load(DR)
'            CI.Creature_On = TheCreature
'            List.Add(CI)
'        Next
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return List
'    End Function
'    Public Shared Function GetAttacks() As Generic.List(Of AttackOld)
'        Dim List As New Generic.List(Of AttackOld)
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,PercentChance, OB, MaxOB, Type, WeaponUsed_ID,Size,ThisRoundSuccess_ID,NextRoundSuccess_ID,Number,DamageMultiplier,CriticalLevel,AdditionalCritsIsOr,UseCriticalInstead,ParentAttack_ID,CreatureOn_ID FROM Attacks"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        For Each DR In DT.Rows
'            Dim CI As New AttackOld
'            CI.Load(DR)
'            List.Add(CI)
'        Next
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return List
'    End Function
'End Class
