'Public Class RangeModOld
'    Public MinValue As Integer
'    Public MaxValue As Integer
'    Public Modifier As Integer


'End Class
'Public Class LevelChartOld
'    Public Class LevelDef
'        Public Code As LevelCode
'        Public RangeList As New Generic.List(Of RangeModOld)

'        Public Function LookupLevel(ByVal Roll As Integer) As Integer
'            Dim RM As RangeModOld
'            For Each RM In RangeList
'                If RM.MinValue <= Roll AndAlso Roll <= RM.MaxValue Then
'                    Return RM.Modifier
'                End If
'            Next
'            Return -20
'        End Function
'    End Class

'    Public LevelDefs As New Generic.Dictionary(Of LevelCode, LevelDef)
'    Public Sub New()

'    End Sub
'    Public Shared Function Load(ByVal DataFile As Xml.XmlDocument) As LevelChartOld
'        Dim LevChart As New LevelChartOld
'        Dim XMl As Xml.XmlDocument
'        XMl = DataFile
'        If XMl Is Nothing Then
'            XMl = New Xml.XmlDocument
'            XMl.Load(My.Application.Info.DirectoryPath & "\datafile.xml")
'        End If
'        Dim XMLElem, Elem2 As Xml.XmlElement
'        Dim XMLList As Xml.XmlNodeList
'        XMLList = XMl.DocumentElement.SelectNodes("LevelChart/Level")
'        For Each XMLElem In XMLList
'            Dim LD As New LevelDef
'            LD.Code = [Enum].Parse(GetType(LevelCode), XMLElem.GetAttribute("Code"))
'            For Each Elem2 In XMLElem.ChildNodes
'                Dim Min As Integer = Elem2.GetAttribute("Min")
'                Dim Max As Integer = Elem2.GetAttribute("Max")
'                Dim Modifier As Integer = Elem2.GetAttribute("Mod")
'                Dim RM As New RangeModOld
'                RM.MinValue = Min
'                RM.MaxValue = Max
'                RM.Modifier = Modifier
'                LD.RangeList.Add(RM)
'            Next
'            LevChart.LevelDefs.Add(LD.Code, LD)
'        Next
'        Return LevChart
'    End Function
'    Public Function LookupLevel(ByVal Roll As Integer, ByVal MyLevelCode As LevelCode) As Integer
'        Return LevelDefs(MyLevelCode).LookupLevel(Roll)
'        'If XMl Is Nothing Then
'        '    XMl = New Xml.XmlDocument
'        '    XMl.Load(My.Application.Info.DirectoryPath & "\datafile.xml")
'        'End If
'        'Dim XMLElem, Elem2 As Xml.XmlElement
'        'XMLElem = XMl.DocumentElement.SelectSingleNode("LevelChart/Level[@Code='" & MyLevelCode.ToString & "']")
'        'For Each Elem2 In XMLElem.ChildNodes
'        '    Dim Min As Integer = Elem2.GetAttribute("Min")
'        '    Dim Max As Integer = Elem2.GetAttribute("Max")
'        '    Dim Modifier As Integer = Elem2.GetAttribute("Mod")
'        '    If Min <= Roll AndAlso Roll <= Max Then
'        '        Return Modifier
'        '    End If
'        'Next
'        'Return -20
'    End Function


'    Public Sub Delete()
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "Delete From Creature_LevelChart"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.ExecuteNonQuery()
'        'ID = 0
'        If Flagg Then DB.ConnEnd()
'    End Sub
'    Public Sub Save()
'        Dim DBEn As New DBEnabled
'        Dim Flagg As Boolean = DBEn.ConnStart()
'        Delete()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        Dim LD As LevelDef
'        For Each LD In LevelDefs.Values
'            Dim RM As RangeModOld
'            For Each RM In LD.RangeList
'                SQL = "Insert into Creature_LevelChart (Code,Min,Max,Mod) values (@Code,@Min,@Max,@Mod)"
'                Cmd = New SqlClient.SqlCommand(SQL, DBEn.MyConn)
'                Cmd.Parameters.Add(New SqlClient.SqlParameter("@Code", LD.Code.ToString))
'                Cmd.Parameters.Add(New SqlClient.SqlParameter("@Min", RM.MinValue))
'                Cmd.Parameters.Add(New SqlClient.SqlParameter("@Max", RM.MaxValue))
'                Cmd.Parameters.Add(New SqlClient.SqlParameter("@Mod", RM.Modifier))
'                Cmd.ExecuteNonQuery()
'            Next
'        Next
'        If Flagg Then DBEn.ConnEnd()
'    End Sub
'    Public Shared Function Load() As LevelChartOld
'        Dim LevChart As New LevelChartOld
'        Dim DBEn As New DBEnabled
'        Dim Flagg As Boolean = DBEn.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "Select Code,Min,Max,Mod from Creature_LevelChart order by Code,Min"
'        Cmd = New SqlClient.SqlCommand(SQL, DBEn.MyConn)
'        Dim Dt As New DataTable
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        DA.Fill(Dt)
'        Dim DR As DataRow
'        Dim LD As New LevelDef
'        If Dt.Rows.Count > 0 Then
'            LD.Code = [Enum].Parse(GetType(LevelCode), Dt.Rows(0)("Code"))
'        End If
'        For Each DR In Dt.Rows
'            Dim LC As LevelCode = [Enum].Parse(GetType(LevelCode), DR("Code"))
'            If LC <> LD.Code Then
'                LevChart.LevelDefs.Add(LD.Code, LD)
'                LD = New LevelDef
'                LD.Code = LC
'            End If
'            Dim RM As New RangeModOld
'            RM.MinValue = DR("Min")
'            RM.MaxValue = DR("Max")
'            RM.Modifier = DR("Mod")
'            LD.RangeList.Add(RM)
'        Next
'        LevChart.LevelDefs.Add(LD.Code, LD)
'        Return LevChart
'    End Function

'End Class
