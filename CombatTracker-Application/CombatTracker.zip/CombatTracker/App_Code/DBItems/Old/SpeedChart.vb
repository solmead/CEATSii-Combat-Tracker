'Public Class SpeedChartOld
'    Public Class SpeedDef
'        Public Speed As MSAQ
'        Public BaseDB As Integer
'        Public FleeEvade As Integer
'        Public ChargeLunge As Integer
'        Public Initiave As Integer
'    End Class
'    Public SpeedDefs As New Generic.Dictionary(Of MSAQ, SpeedDef)
'    Public Shared Function Load(ByVal DataFile As Xml.XmlDocument) As SpeedChartOld
'        Dim SC As New SpeedChartOld
'        Dim XMl As Xml.XmlDocument
'        XMl = DataFile
'        If XMl Is Nothing Then
'            XMl = New Xml.XmlDocument
'            XMl.Load(My.Application.Info.DirectoryPath & "\datafile.xml")
'        End If
'        Dim XMLElem, Elem2 As Xml.XmlElement
'        Dim XMLList As Xml.XmlNodeList
'        XMLList = XMl.DocumentElement.SelectNodes("SpeedChart/MSBaseDB/Speed")
'        For Each XMLElem In XMLList
'            Dim SD As SpeedDef
'            Dim MA As MSAQ = [Enum].Parse(GetType(MSAQ), XMLElem.GetAttribute("Name"))
'            If SC.SpeedDefs.ContainsKey(MA) Then
'                SD = SC.SpeedDefs(MA)
'            Else
'                SD = New SpeedDef
'                SD.Speed = MA
'                SC.SpeedDefs.Add(SD.Speed, SD)
'            End If
'            SD.BaseDB = CInt(XMLElem.GetAttribute("Num"))
'        Next
'        XMLList = XMl.DocumentElement.SelectNodes("SpeedChart/MSFleeEvade/Speed")
'        For Each XMLElem In XMLList
'            Dim SD As SpeedDef
'            Dim MA As MSAQ = [Enum].Parse(GetType(MSAQ), XMLElem.GetAttribute("Name"))
'            If SC.SpeedDefs.ContainsKey(MA) Then
'                SD = SC.SpeedDefs(MA)
'            Else
'                SD = New SpeedDef
'                SD.Speed = MA
'                SC.SpeedDefs.Add(SD.Speed, SD)
'            End If
'            SD.FleeEvade = CInt(XMLElem.GetAttribute("Num"))
'        Next
'        XMLList = XMl.DocumentElement.SelectNodes("SpeedChart/AQChargeLunge/Speed")
'        For Each XMLElem In XMLList
'            Dim SD As SpeedDef
'            Dim MA As MSAQ = [Enum].Parse(GetType(MSAQ), XMLElem.GetAttribute("Name"))
'            If SC.SpeedDefs.ContainsKey(MA) Then
'                SD = SC.SpeedDefs(MA)
'            Else
'                SD = New SpeedDef
'                SD.Speed = MA
'                SC.SpeedDefs.Add(SD.Speed, SD)
'            End If
'            SD.ChargeLunge = CInt(XMLElem.GetAttribute("Num"))
'        Next
'        XMLList = XMl.DocumentElement.SelectNodes("SpeedChart/AQInitiative/Speed")
'        For Each XMLElem In XMLList
'            Dim SD As SpeedDef
'            Dim MA As MSAQ = [Enum].Parse(GetType(MSAQ), XMLElem.GetAttribute("Name"))
'            If SC.SpeedDefs.ContainsKey(MA) Then
'                SD = SC.SpeedDefs(MA)
'            Else
'                SD = New SpeedDef
'                SD.Speed = MA
'                SC.SpeedDefs.Add(SD.Speed, SD)
'            End If
'            SD.Initiave = CInt(XMLElem.GetAttribute("Num"))
'        Next

'        Return SC
'    End Function
'    'Public Function LookupBaseDB(ByVal MS As MSAQ) As Integer
'    '    If XMl Is Nothing Then
'    '        XMl = New Xml.XmlDocument
'    '        XMl.Load(My.Application.Info.DirectoryPath & "\datafile.xml")
'    '    End If
'    '    Dim XMLElem As Xml.XmlElement
'    '    XMLElem = XMl.DocumentElement.SelectSingleNode("SpeedChart/MSBaseDB/Speed[@Name='" & MS.ToString & "']")
'    '    Dim Modifier As Integer = XMLElem.GetAttribute("Num")
'    '    Return Modifier
'    'End Function
'    'Public Function LookupFleeEvade(ByVal MS As MSAQ) As Integer
'    '    If XMl Is Nothing Then
'    '        XMl = New Xml.XmlDocument
'    '        XMl.Load(My.Application.Info.DirectoryPath & "\datafile.xml")
'    '    End If
'    '    Dim XMLElem As Xml.XmlElement
'    '    XMLElem = XMl.DocumentElement.SelectSingleNode("SpeedChart/MSFleeEvade/Speed[@Name='" & MS.ToString & "']")
'    '    Dim Modifier As Integer = XMLElem.GetAttribute("Num")
'    '    Return Modifier
'    'End Function
'    'Public Function LookupChargeLunge(ByVal AQ As MSAQ) As Integer
'    '    If XMl Is Nothing Then
'    '        XMl = New Xml.XmlDocument
'    '        XMl.Load(My.Application.Info.DirectoryPath & "\datafile.xml")
'    '    End If
'    '    Dim XMLElem As Xml.XmlElement
'    '    XMLElem = XMl.DocumentElement.SelectSingleNode("SpeedChart/AQChargeLunge/Speed[@Name='" & AQ.ToString & "']")
'    '    Dim Modifier As Integer = XMLElem.GetAttribute("Num")
'    '    Return Modifier
'    'End Function
'    'Public Function LookupInitiative(ByVal AQ As MSAQ) As Integer
'    '    If XMl Is Nothing Then
'    '        XMl = New Xml.XmlDocument
'    '        XMl.Load(My.Application.Info.DirectoryPath & "\datafile.xml")
'    '    End If
'    '    Dim XMLElem As Xml.XmlElement
'    '    XMLElem = XMl.DocumentElement.SelectSingleNode("SpeedChart/AQInitiative/Speed[@Name='" & AQ.ToString & "']")
'    '    Dim Modifier As Integer = XMLElem.GetAttribute("Num")
'    '    Return Modifier
'    'End Function
'    Public Sub Delete()
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "Delete From Creature_SpeedChart"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.ExecuteNonQuery()
'        'ID = 0
'        If Flagg Then DB.ConnEnd()
'    End Sub
'    Public Sub Save()
'        Dim DBEn As New DBEnabled
'        Dim Flagg As Boolean = DBEn.ConnStart()
'        Delete()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        Dim LD As SpeedDef
'        For Each LD In SpeedDefs.Values
'            SQL = "Insert into Creature_SpeedChart ( Name, MSBaseDB, MSFleeEvade, AQChargeLunge, AQInitiative) values (@Name, @MSBaseDB, @MSFleeEvade, @AQChargeLunge, @AQInitiative)"
'            Cmd = New SqlClient.SqlCommand(SQL, DBEn.MyConn)
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@Name", LD.Speed.ToString))
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@MSBaseDB", LD.BaseDB))
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@MSFleeEvade", LD.FleeEvade))
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@AQChargeLunge", LD.ChargeLunge))
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@AQInitiative", LD.Initiave))
'            Cmd.ExecuteNonQuery()
'        Next
'        If Flagg Then DBEn.ConnEnd()
'    End Sub
'    Public Shared Function Load() As SpeedChartOld
'        Dim LevChart As New SpeedChartOld
'        Dim DBEn As New DBEnabled
'        Dim Flagg As Boolean = DBEn.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "Select  Name, MSBaseDB, MSFleeEvade, AQChargeLunge, AQInitiative from Creature_SpeedChart order by Name"
'        Cmd = New SqlClient.SqlCommand(SQL, DBEn.MyConn)
'        Dim Dt As New DataTable
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        DA.Fill(Dt)
'        Dim DR As DataRow
'        For Each DR In Dt.Rows
'            Dim LD As New SpeedDef
'            LD.Speed = [Enum].Parse(GetType(MSAQ), DR("Name"))
'            LD.BaseDB = DR("MSBaseDB")
'            LD.FleeEvade = DR("MSFleeEvade")
'            LD.ChargeLunge = DR("AQChargeLunge")
'            LD.Initiave = DR("AQInitiative")
'            LevChart.SpeedDefs.Add(LD.Speed, LD)
'        Next
'        Return LevChart
'    End Function
'End Class
