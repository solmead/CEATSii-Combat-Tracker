'Public Class ConstitutionBonusChartOld
'    Public Class ConstitutionDef
'        Public Code As HitCode
'        Public HitsLevelDifference As Integer
'        Public BonusExhaustion As Integer
'        Public StaminaList As New Generic.List(Of RangeModOld)

'        Public Function LookupStamina(ByVal Roll As Integer) As Integer
'            'Dim R = (From R2 In StaminaList Where R2.MinValue <= Roll And Roll <= R2.MaxValue Select R2.Modifier).First

'            Dim RM As RangeModOld
'            For Each RM In StaminaList
'                If RM.MinValue <= Roll AndAlso Roll <= RM.MaxValue Then
'                    Return RM.Modifier
'                End If
'            Next
'            Return -20
'        End Function
'    End Class

'    Public ConstitutionDefs As New Generic.Dictionary(Of HitCode, ConstitutionDef)

'    Public Shared Function Load(ByVal DataFile As Xml.XmlDocument) As ConstitutionBonusChartOld
'        Dim ConBonusChart As New ConstitutionBonusChartOld
'        Dim XMl As Xml.XmlDocument
'        XMl = DataFile
'        If XMl Is Nothing Then
'            XMl = New Xml.XmlDocument
'            XMl.Load(My.Application.Info.DirectoryPath & "\datafile.xml")
'        End If
'        Dim XMLElem, Elem2 As Xml.XmlElement
'        Dim XMLList As Xml.XmlNodeList
'        XMLList = XMl.DocumentElement.SelectNodes("ConstitutionBonusChart/Hits")
'        For Each XMLElem In XMLList
'            Dim LD As New ConstitutionDef
'            LD.Code = [Enum].Parse(GetType(HitCode), XMLElem.GetAttribute("Code"))
'            LD.BonusExhaustion = CInt(XMLElem.GetAttribute("BonusExhaustion"))
'            LD.HitsLevelDifference = CInt(XMLElem.GetAttribute("PerLevelDiff"))
'            For Each Elem2 In XMLElem.ChildNodes
'                Dim Min As Integer = Elem2.GetAttribute("Min")
'                Dim Max As Integer = Elem2.GetAttribute("Max")
'                Dim Modifier As Integer = Elem2.GetAttribute("Mod")
'                Dim RM As New RangeModOld
'                RM.MinValue = Min
'                RM.MaxValue = Max
'                RM.Modifier = Modifier
'                LD.StaminaList.Add(RM)
'            Next
'            ConBonusChart.ConstitutionDefs.Add(LD.Code, LD)
'        Next
'        Return ConBonusChart
'    End Function
'    Public Function LookupStamina(ByVal Roll As Integer, ByVal BaseHitCode As HitCode) As Integer
'        Return ConstitutionDefs(BaseHitCode).LookupStamina(Roll)
'    End Function
'    'Public Function LookupHitsLevelDiff(ByVal BaseHitCode As HitCode) As Integer
'    '    If XMl Is Nothing Then
'    '        XMl = New Xml.XmlDocument
'    '        XMl.Load(My.Application.Info.DirectoryPath & "\datafile.xml")
'    '    End If
'    '    Dim XMLElem As Xml.XmlElement
'    '    XMLElem = XMl.DocumentElement.SelectSingleNode("ConstitutionBonusChart/Hits[@Code='" & BaseHitCode.ToString & "']")
'    '    Return CInt(XMLElem.GetAttribute("PerLevelDiff"))
'    'End Function
'    'Public Function LookupBonusExhaustion(ByVal BaseHitCode As HitCode) As Integer
'    '    If XMl Is Nothing Then
'    '        XMl = New Xml.XmlDocument
'    '        XMl.Load(My.Application.Info.DirectoryPath & "\datafile.xml")
'    '    End If
'    '    Dim XMLElem As Xml.XmlElement
'    '    XMLElem = XMl.DocumentElement.SelectSingleNode("ConstitutionBonusChart/Hits[@Code='" & BaseHitCode.ToString & "']")
'    '    Return CInt(XMLElem.GetAttribute("BonusExhaustion"))
'    'End Function

'    Public Sub Delete()
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "Delete From Creature_ConstitutionBonusChart"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.ExecuteNonQuery()
'        'ID = 0
'        If Flagg Then DB.ConnEnd()
'    End Sub
'    Public Sub Save()
'        Dim DBEn As New DBEnabled
'        Dim Flagg As Boolean = DBEn.ConnStart()
'        Delete()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        Dim LD As ConstitutionDef
'        For Each LD In ConstitutionDefs.Values
'            Dim RM As RangeModOld
'            For Each RM In LD.StaminaList
'                SQL = "Insert into Creature_ConstitutionBonusChart (Code,Min,Max,Mod,PerLevelDifference, BonusExhaustion) values (@Code,@Min,@Max,@Mod,@PerLevelDifference, @BonusExhaustion)"
'                Cmd = New SqlClient.SqlCommand(SQL, DBEn.MyConn)
'                Cmd.Parameters.Add(New SqlClient.SqlParameter("@Code", LD.Code.ToString))
'                Cmd.Parameters.Add(New SqlClient.SqlParameter("@Min", RM.MinValue))
'                Cmd.Parameters.Add(New SqlClient.SqlParameter("@Max", RM.MaxValue))
'                Cmd.Parameters.Add(New SqlClient.SqlParameter("@Mod", RM.Modifier))
'                Cmd.Parameters.Add(New SqlClient.SqlParameter("@PerLevelDifference", LD.HitsLevelDifference))
'                Cmd.Parameters.Add(New SqlClient.SqlParameter("@BonusExhaustion", LD.BonusExhaustion))
'                Cmd.ExecuteNonQuery()
'            Next
'        Next
'        If Flagg Then DBEn.ConnEnd()
'    End Sub
'    Public Shared Function Load() As ConstitutionBonusChartOld
'        Dim LevChart As New ConstitutionBonusChartOld
'        Dim DBEn As New DBEnabled
'        Dim Flagg As Boolean = DBEn.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "Select Code,Min,Max,Mod,PerLevelDifference, BonusExhaustion from Creature_ConstitutionBonusChart order by Code,Min"
'        Cmd = New SqlClient.SqlCommand(SQL, DBEn.MyConn)
'        Dim Dt As New DataTable
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        DA.Fill(Dt)
'        Dim DR As DataRow
'        Dim LD As New ConstitutionDef
'        If Dt.Rows.Count > 0 Then
'            LD.Code = [Enum].Parse(GetType(HitCode), Dt.Rows(0)("Code"))
'            LD.HitsLevelDifference = Dt.Rows(0)("PerLevelDifference")
'            LD.BonusExhaustion = Dt.Rows(0)("BonusExhaustion")
'        End If
'        For Each DR In Dt.Rows
'            Dim LC As LevelCode = [Enum].Parse(GetType(HitCode), DR("Code"))
'            If LC <> LD.Code Then
'                LevChart.ConstitutionDefs.Add(LD.Code, LD)
'                LD = New ConstitutionDef
'                LD.Code = LC
'                LD.HitsLevelDifference = DR("PerLevelDifference")
'                LD.BonusExhaustion = DR("BonusExhaustion")
'            End If
'            Dim RM As New RangeModOld
'            RM.MinValue = DR("Min")
'            RM.MaxValue = DR("Max")
'            RM.Modifier = DR("Mod")
'            LD.StaminaList.Add(RM)
'        Next
'        LevChart.ConstitutionDefs.Add(LD.Code, LD)
'        Return LevChart
'    End Function
'End Class
