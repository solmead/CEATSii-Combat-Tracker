
'Public Enum LevelCode
'    A
'    B
'    C
'    D
'    E
'    F
'    G
'    H
'End Enum
'Public Enum HitCode
'    A
'    B
'    C
'    D
'    E
'    F
'    G
'    H
'End Enum
'Public Enum MSAQ
'    Inching
'    Creeping
'    Very_Slow
'    Slow
'    Medium
'    Moderately_Fast
'    Fast
'    Very_Fast
'    Blindingly_Fast
'End Enum
'Public Enum SizeRating
'    Tiny
'    Small
'    Medium
'    Large
'    Huge
'End Enum
'Public Enum Pace
'    Walk
'    Jog
'    Run
'    Sprint
'    Fast_Sprint
'    Dash
'End Enum
'Public Enum CritTypes
'    None
'    Slash
'    Puncture
'    Krush
'    Unbalance
'    Grappling
'    Tiny_Animals
'    Heat
'    Cold
'    Brawling
'    Martial_Arts_Strikes
'    Martial_Arts_Sweeps
'    Large_Creature_Physical
'    Super_Large_Creature_Physical
'    Large_Creature_Spells
'    Super_Large_Creature_Spells
'    Electricity
'    Impact
'End Enum
'Public Enum CriticalLevels
'    Same
'    A
'    B
'    C
'    D
'    E
'End Enum
'Public Enum CriticalCode
'    Normal
'    Decrease_By_One
'    Decrease_By_Two
'    Large_Critical
'    SuperLarge_Critical
'End Enum
'Public Enum CharacterType
'    NPC
'    PC
'End Enum
'Public Enum AttackType
'    Bash
'    Bite
'    Claw
'    Crush
'    Grapple
'    Pincer
'    Horn
'    Stinger
'    Tiny
'    Trample
'    Brawling
'    Weapon
'    Martial_Arts_Sweep
'    Martial_Arts_Striking
'    Poison
'    Spell
'    Special
'    Bolt
'    Cone
'    Ball
'    Fire_Bolt
'    Ice_Bolt
'    Lightning_Bolt
'    Shock_Bolt
'    Water_Bolt
'    Cold_Ball
'    Fire_Ball
'    Cold_Cone
'    Fire_Cone
'    Gas_Cone
'    Shock_Cone
'    Lightning_Cone

'End Enum


'<Serializable()> Public Class CreatureOld
'    Implements System.Runtime.Serialization.ISerializable


'    Private m_TypeName As String
'    Private m_BaseLevel As Integer
'    Private m_LevelMod As LevelCode
'    Private m_Size As SizeRating
'    Private m_MSRating As MSAQ
'    Private m_AQRating As MSAQ
'    Private m_BaseMove As Integer
'    Private m_MaxPace As Pace
'    Private m_MMBonus As Integer
'    Private m_MinEncountered As Integer
'    Private m_MaxEncountered As Integer
'    'public Treasure as
'    Private m_BaseHits As Integer
'    Private m_HitMod As HitCode
'    Private m_Criticals As CriticalCode
'    Private m_IgnoreStun As Boolean
'    Private m_IgnoreBleeders As Boolean
'    Private m_AT As Integer
'    Private m_DB As Integer
'    Private m_Attacks As List(Of AttackOld) '= New ArrayList
'    Private m_Habitat As New ArrayList
'    Private m_Outlook As String
'    Private m_IQ As String
'    Private m_PageNumber As Integer
'    Private m_Book As String
'    Private m_Description As String = ""
'    Private m_ID As Integer

'    '

'    Public Sub New()

'    End Sub
'    Public Sub New(ByVal info As System.Runtime.Serialization.SerializationInfo, ByVal context As System.Runtime.Serialization.StreamingContext)
'        TypeName = info.GetString("TypeName")
'        BaseLevel = info.GetInt32("BaseLevel")
'        LevelMod = info.GetInt32("LevelMod")
'        Size = info.GetInt32("Size")
'        MSRating = info.GetInt32("MSRating")
'        AQRating = info.GetInt32("AQRating")
'        BaseMove = info.GetInt32("BaseMove")
'        MaxPace = info.GetInt32("MaxPace")
'        MMBonus = info.GetInt32("MMBonus")
'        MinEncountered = info.GetInt32("MinEncountered")
'        MaxEncountered = info.GetInt32("MaxEncountered")
'        BaseHits = info.GetInt32("BaseHits")
'        HitMod = info.GetInt32("HitMod")
'        Criticals = info.GetInt32("Criticals")
'        IgnoreStun = info.GetBoolean("IgnoreStun")
'        IgnoreBleeders = info.GetBoolean("IgnoreBleeders")
'        AT = info.GetInt32("AT")
'        DB = info.GetInt32("DB")
'        Attacks = info.GetValue("Attacks", GetType(List(Of AttackOld)))
'        Habitat = info.GetValue("Habitat", GetType(ArrayList))
'        IQ = info.GetString("IQ")
'        Outlook = info.GetString("Outlook")
'        PageNumber = info.GetInt32("PageNumber")
'        Book = info.GetString("Book")
'        Description = info.GetString("Description")

'    End Sub

'    Public Property ID() As Integer
'        Get
'            Return m_ID
'        End Get
'        Set(ByVal Value As Integer)
'            m_ID = Value
'        End Set
'    End Property

'    Public Property TypeName() As String
'        Get
'            Return m_TypeName
'        End Get
'        Set(ByVal Value As String)
'            m_TypeName = Value
'        End Set
'    End Property

'    Public Property BaseLevel() As Integer
'        Get
'            Return m_BaseLevel
'        End Get
'        Set(ByVal Value As Integer)
'            m_BaseLevel = Value
'        End Set
'    End Property

'    Public Property LevelMod() As LevelCode
'        Get
'            Return m_LevelMod
'        End Get
'        Set(ByVal Value As LevelCode)
'            m_LevelMod = Value
'        End Set
'    End Property

'    Public Property Size() As SizeRating
'        Get
'            Return m_Size
'        End Get
'        Set(ByVal Value As SizeRating)
'            m_Size = Value
'        End Set
'    End Property

'    Public Property MSRating() As MSAQ
'        Get
'            Return m_MSRating
'        End Get
'        Set(ByVal Value As MSAQ)
'            m_MSRating = Value
'        End Set
'    End Property

'    Public Property AQRating() As MSAQ
'        Get
'            Return m_AQRating
'        End Get
'        Set(ByVal Value As MSAQ)
'            m_AQRating = Value
'        End Set
'    End Property

'    Public Property BaseMove() As Integer
'        Get
'            Return m_BaseMove
'        End Get
'        Set(ByVal Value As Integer)
'            m_BaseMove = Value
'        End Set
'    End Property

'    Public Property MaxPace() As Pace
'        Get
'            Return m_MaxPace
'        End Get
'        Set(ByVal Value As Pace)
'            m_MaxPace = Value
'        End Set
'    End Property

'    Public Property MMBonus() As Integer
'        Get
'            Return m_MMBonus
'        End Get
'        Set(ByVal Value As Integer)
'            m_MMBonus = Value
'        End Set
'    End Property

'    Public Property MinEncountered() As Integer
'        Get
'            Return m_MinEncountered
'        End Get
'        Set(ByVal Value As Integer)
'            m_MinEncountered = Value
'        End Set
'    End Property

'    Public Property MaxEncountered() As Integer
'        Get
'            Return m_MaxEncountered
'        End Get
'        Set(ByVal Value As Integer)
'            m_MaxEncountered = Value
'        End Set
'    End Property

'    Public Property BaseHits() As Integer
'        Get
'            Return m_BaseHits
'        End Get
'        Set(ByVal Value As Integer)
'            m_BaseHits = Value
'        End Set
'    End Property

'    Public Property HitMod() As HitCode
'        Get
'            Return m_HitMod
'        End Get
'        Set(ByVal Value As HitCode)
'            m_HitMod = Value
'        End Set
'    End Property

'    Public Property Criticals() As CriticalCode
'        Get
'            Return m_Criticals
'        End Get
'        Set(ByVal Value As CriticalCode)
'            m_Criticals = Value
'        End Set
'    End Property

'    Public Property IgnoreStun() As Boolean
'        Get
'            Return m_IgnoreStun
'        End Get
'        Set(ByVal Value As Boolean)
'            m_IgnoreStun = Value
'        End Set
'    End Property

'    Public Property IgnoreBleeders() As Boolean
'        Get
'            Return m_IgnoreBleeders
'        End Get
'        Set(ByVal Value As Boolean)
'            m_IgnoreBleeders = Value
'        End Set
'    End Property

'    Public Property AT() As Integer
'        Get
'            Return m_AT
'        End Get
'        Set(ByVal Value As Integer)
'            m_AT = Value
'        End Set
'    End Property

'    Public Property DB() As Integer
'        Get
'            Return m_DB
'        End Get
'        Set(ByVal Value As Integer)
'            m_DB = Value
'        End Set
'    End Property

'    Public Property Attacks() As List(Of AttackOld)
'        Get
'            If m_Attacks Is Nothing Then
'                m_Attacks = AttackOld.GetAttacksOnCreature(Me)
'            End If
'            Return m_Attacks
'        End Get
'        Set(ByVal Value As List(Of AttackOld))
'            m_Attacks = Value
'        End Set
'    End Property

'    Public Property Habitat() As ArrayList
'        Get
'            Return m_Habitat
'        End Get
'        Set(ByVal Value As ArrayList)
'            m_Habitat = Value
'        End Set
'    End Property

'    Public Property Outlook() As String
'        Get
'            Return m_Outlook
'        End Get
'        Set(ByVal Value As String)
'            m_Outlook = Value
'        End Set
'    End Property

'    Public Property IQ() As String
'        Get
'            Return m_IQ
'        End Get
'        Set(ByVal Value As String)
'            m_IQ = Value
'        End Set
'    End Property

'    Public Property PageNumber() As Integer
'        Get
'            Return m_PageNumber
'        End Get
'        Set(ByVal Value As Integer)
'            m_PageNumber = Value
'        End Set
'    End Property

'    Public Property Book() As String
'        Get
'            Return m_Book
'        End Get
'        Set(ByVal Value As String)
'            m_Book = Value
'        End Set
'    End Property

'    Public Property Description() As String
'        Get
'            Return m_Description
'        End Get
'        Set(ByVal Value As String)
'            m_Description = Value
'        End Set
'    End Property


'    'Public Function Clone() As Creature
'    '    Dim ms As System.IO.MemoryStream
'    '    ms = Handler.PackData(Me)
'    '    Dim Cr As Creature = Handler.UnPackData(ms)
'    '    Return Cr
'    'End Function
'    Public Overrides Function ToString() As String
'        Return TypeName '& " - " & Book & ", " & PageNumber
'    End Function
'    Private Function GetLevel()
'        Dim Roll As Integer = RollD100OpenEnded()
'        Dim Level As Integer = BaseLevel + RMSS.LevelChart.LookupLevel(Roll, LevelMod)
'        If Level < 0 Then Level = 0
'        Return Level
'    End Function
'    Public Function GetActor(ByVal MD As MasterData) As Actor
'        Dim MyChar As New Actor
'        MyChar.BaseCreature = Me
'        Dim Arm As ArmorOld
'        For Each Arm In MD.ArmorList
'            If Arm.Type = AT Then
'                MyChar.CurrentArmor = Arm.Clone
'                MyChar.ArmorList.Add(MyChar.CurrentArmor)
'            End If
'        Next
'        If MyChar.CurrentArmor Is Nothing Then
'            Dim Ar As New ArmorOld
'            Ar.Type = AT
'            Ar.Description = "Unknown"
'            MD.ArmorList.Add(Ar)
'            MyChar.CurrentArmor = Ar.Clone
'            MyChar.ArmorList.Add(MyChar.CurrentArmor)
'        End If
'        MyChar.CurrentArmor.DB = DB
'        MyChar.Level = Me.GetLevel()
'        MyChar.BaseInititive = RMSS.SpeedChart.SpeedDefs(Me.AQRating).Initiave
'        Dim Roll As Integer = RMSS.RollOnes()
'        If Roll = 0 Then Roll = 10
'        MyChar.RolledInititive = Roll
'        Roll = RMSS.RollOnes()
'        If Roll = 0 Then Roll = 10
'        MyChar.RolledInititive += Roll
'        Roll = RMSS.RollD100()
'        MyChar.HitsTotal = Me.BaseHits + RMSS.ConBonusChart.LookupStamina(Roll, HitMod) + (MyChar.Level - Me.BaseLevel) * RMSS.ConBonusChart.ConstitutionDefs(HitMod).HitsLevelDifference
'        MyChar.HitsRemaining = MyChar.HitsTotal
'        MyChar.ExhaustionTotal = RMSS.ConBonusChart.LookupStamina(Roll, HitMod) * 3 + 40 + RMSS.ConBonusChart.ConstitutionDefs(HitMod).BonusExhaustion
'        MyChar.ExhaustionRemaining = MyChar.ExhaustionTotal
'        MyChar.Type = CharacterType.NPC
'        Dim Atk As AttackOld
'        For Each Atk In Me.Attacks
'            Dim atk2 As AttackOld = Atk.Clone
'            atk2.ModifyOB((MyChar.Level - Me.BaseLevel))
'            MyChar.Attacks.Add(atk2)
'        Next
'        'Roll = RMSS.RollD100
'        'Dim Cnt As Integer = 0
'        'For Each Atk In MyChar.Attacks
'        '    Cnt += Atk.PercentChance
'        '    If Cnt >= Roll Then
'        '        MyChar.CurrentAttack = Atk
'        '        Exit For
'        '    End If
'        'Next


'        'MyChar.IsConcentrating = True
'        'MyChar.UnderHaste = True
'        'MyChar.Suprised = True
'        'MyChar.UsingAdrenalDB = True

'        Dim Ac As New StandardAction
'        Ac.Name = "Wait"
'        Ac.WhoIsActing = MyChar
'        MyChar.SetActionTime(Ac, MD)
'        MD.Actions.Add(Ac)
'        MyChar.CurrentAction(MD) = Ac
'        Return MyChar
'    End Function



'    Public Sub GetObjectData(ByVal info As System.Runtime.Serialization.SerializationInfo, ByVal context As System.Runtime.Serialization.StreamingContext) Implements System.Runtime.Serialization.ISerializable.GetObjectData

'    End Sub



'    Public Sub Delete()
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "Delete From Creatures where ID=@ID"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'        Cmd.ExecuteNonQuery()
'        Dim Atk As AttackOld
'        For Each Atk In Attacks
'            Atk.Delete()
'        Next
'        ID = 0
'        If Flagg Then DB.ConnEnd()
'    End Sub
'    Public Sub Save()
'        Dim DBEn As New DBEnabled
'        Dim Flagg As Boolean = DBEn.ConnStart()

'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        If ID = 0 Then
'            SQL = "Insert into Creatures (TypeName, BaseLevel, LevelMod, Size, MSRating, AQRating, BaseMove, MaxPace, MMBonus, MinEncountered, MaxEncountered, BaseHits, HitMod, Criticals, IgnoreStun, IgnoreBleeders, AT, DB, Outlook, IQ, PageNumber, Book, Description) values (@TypeName, @BaseLevel, @LevelMod, @Size, @MSRating, @AQRating, @BaseMove, @MaxPace, @MMBonus, @MinEncountered, @MaxEncountered, @BaseHits, @HitMod, @Criticals, @IgnoreStun, @IgnoreBleeders, @AT, @DB, @Outlook, @IQ, @PageNumber, @Book, @Description); Select @@Identity"
'        Else
'            SQL = "Update Creatures Set TypeName=@TypeName, BaseLevel=@BaseLevel, LevelMod=@LevelMod, Size=@Size, MSRating=@MSRating, AQRating=@AQRating, BaseMove=@BaseMove, MaxPace=@MaxPace, MMBonus=@MMBonus, MinEncountered=@MinEncountered, MaxEncountered=@MaxEncountered, BaseHits=@BaseHits, HitMod=@HitMod, Criticals=@Criticals, IgnoreStun=@IgnoreStun, IgnoreBleeders=@IgnoreBleeders, AT=@AT, DB=@DB, Outlook=@Outlook, IQ=@IQ, PageNumber=@PageNumber, Book=@Book, Description=@Description Where ID=@ID"
'        End If
'        Cmd = New SqlClient.SqlCommand(SQL, DBEn.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@TypeName", TypeName))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@BaseLevel", BaseLevel))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@LevelMod", LevelMod.ToString))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Size", Size.ToString))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@MSRating", MSRating.ToString))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@AQRating", AQRating.ToString))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@BaseMove", BaseMove))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@MaxPace", MaxPace.ToString))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@MMBonus", MMBonus))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@MinEncountered", MinEncountered))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@MaxEncountered", MaxEncountered))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@BaseHits", BaseHits))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@HitMod", HitMod.ToString))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Criticals", Criticals.ToString))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@IgnoreStun", IgnoreStun))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@IgnoreBleeders", IgnoreBleeders))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@AT", AT))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@DB", DB))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Outlook", HandleNull(Outlook)))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@IQ", HandleNull(IQ)))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@PageNumber", PageNumber))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Book", Book))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Description", HandleNull(Description)))



'        If ID = 0 Then
'            ID = Cmd.ExecuteScalar
'        Else
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'            Cmd.ExecuteNonQuery()
'        End If
'        If m_Attacks IsNot Nothing Then
'            Dim Atk As AttackOld
'            For Each Atk In Attacks
'                Atk.Creature_On = Me
'                Atk.Save()
'            Next
'        End If
'        If Flagg Then DBEn.ConnEnd()
'    End Sub

'    Private Sub Load(ByVal DR As DataRow)
'        'TypeName, BaseLevel, LevelMod, Size, MSRating, AQRating, BaseMove, MaxPace, MMBonus, MinEncountered, MaxEncountered, BaseHits, HitMod, Criticals, IgnoreStun, IgnoreBleeders, AT, DB, Outlook, IQ, PageNumber, Book, Description
'        ID = CInt(GetData(DR, "ID"))
'        TypeName = GetData(DR, "TypeName")
'        BaseLevel = CInt(GetData(DR, "BaseLevel"))
'        LevelMod = [Enum].Parse(GetType(LevelCode), GetData(DR, "LevelMod"))
'        Size = [Enum].Parse(GetType(SizeRating), GetData(DR, "Size"))
'        MSRating = [Enum].Parse(GetType(MSAQ), GetData(DR, "MSRating"))
'        AQRating = [Enum].Parse(GetType(MSAQ), GetData(DR, "AQRating"))
'        BaseMove = CInt(GetData(DR, "BaseMove"))
'        MaxPace = [Enum].Parse(GetType(Pace), GetData(DR, "MaxPace"))
'        MMBonus = CInt(GetData(DR, "MMBonus"))
'        MinEncountered = CInt(GetData(DR, "MinEncountered"))
'        MaxEncountered = CInt(GetData(DR, "MaxEncountered"))
'        BaseHits = CInt(GetData(DR, "BaseHits"))
'        HitMod = [Enum].Parse(GetType(HitCode), GetData(DR, "HitMod"))
'        Criticals = [Enum].Parse(GetType(CriticalCode), GetData(DR, "Criticals"))
'        IgnoreStun = CBool(GetData(DR, "IgnoreStun"))
'        IgnoreBleeders = CBool(GetData(DR, "IgnoreBleeders"))
'        AT = CInt(GetData(DR, "AT"))
'        DB = CInt(GetData(DR, "DB"))
'        Outlook = (GetData(DR, "Outlook"))
'        IQ = (GetData(DR, "IQ"))
'        PageNumber = CInt(GetData(DR, "PageNumber"))
'        Book = (GetData(DR, "Book"))
'        Description = (GetData(DR, "Description"))
'    End Sub
'    Public Shared Function Load(ByVal ID As Integer) As CreatureOld
'        Dim DB As New DBEnabled
'        Dim CI As New CreatureOld
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,TypeName, BaseLevel, LevelMod, Size, MSRating, AQRating, BaseMove, MaxPace, MMBonus, MinEncountered, MaxEncountered, BaseHits, HitMod, Criticals, IgnoreStun, IgnoreBleeders, AT, DB, Outlook, IQ, PageNumber, Book, Description FROM Creatures where ID=@ID"

'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        If DT.Rows.Count > 0 Then
'            DR = DT.Rows(0)
'            CI.Load(DR)
'        End If
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return CI
'    End Function
'    Public Shared Function GetCreatures() As Generic.List(Of CreatureOld)
'        Dim List As New Generic.List(Of CreatureOld)
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,TypeName, BaseLevel, LevelMod, Size, MSRating, AQRating, BaseMove, MaxPace, MMBonus, MinEncountered, MaxEncountered, BaseHits, HitMod, Criticals, IgnoreStun, IgnoreBleeders, AT, DB, Outlook, IQ, PageNumber, Book, Description FROM Creatures"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        For Each DR In DT.Rows
'            Dim CI As New CreatureOld
'            CI.Load(DR)
'            List.Add(CI)
'        Next
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return List
'    End Function
'End Class
