
'<Serializable()> Public Class PreBuiltCharOld
'    Implements System.Runtime.Serialization.ISerializable

'    Private m_ID As Integer
'    Private m_Name As String
'    Private m_Level As Integer
'    Private m_BaseInititive As Integer
'    Private m_HitPoints As Integer
'    Private m_ExhaustionPoints As Integer
'    Private m_PowerPoints As Integer
'    Private m_Armors As List(Of ArmorOld)
'    Private m_Weapons As List(Of WeaponOld)
'    Private m_Type As CharacterType
'    Private m_StrengthBonus As Integer

'    Private m_PercentRequiredAdrenalDB As Double = 0.4
'    Public Property PercentRequiredAdrenalDB() As Double
'        Get
'            Return m_PercentRequiredAdrenalDB
'        End Get
'        Set(ByVal Value As Double)
'            m_PercentRequiredAdrenalDB = Value
'        End Set
'    End Property



'    Public Property ID() As Integer
'        Get
'            Return m_ID
'        End Get
'        Set(ByVal Value As Integer)
'            m_ID = Value
'        End Set
'    End Property

'    Public Property Name() As String
'        Get
'            Return m_Name
'        End Get
'        Set(ByVal Value As String)
'            m_Name = Value
'        End Set
'    End Property

'    Public Property Level() As Integer
'        Get
'            Return m_Level
'        End Get
'        Set(ByVal Value As Integer)
'            m_Level = Value
'        End Set
'    End Property

'    Public Property BaseInititive() As Integer
'        Get
'            Return m_BaseInititive
'        End Get
'        Set(ByVal Value As Integer)
'            m_BaseInititive = Value
'        End Set
'    End Property

'    Public Property HitPoints() As Integer
'        Get
'            Return m_HitPoints
'        End Get
'        Set(ByVal Value As Integer)
'            m_HitPoints = Value
'        End Set
'    End Property

'    Public Property ExhaustionPoints() As Integer
'        Get
'            Return m_ExhaustionPoints
'        End Get
'        Set(ByVal Value As Integer)
'            m_ExhaustionPoints = Value
'        End Set
'    End Property

'    Public Property PowerPoints() As Integer
'        Get
'            Return m_PowerPoints
'        End Get
'        Set(ByVal Value As Integer)
'            m_PowerPoints = Value
'        End Set
'    End Property

'    Public Property Armors() As List(Of ArmorOld)
'        Get
'            If m_Armors Is Nothing Then
'                m_Armors = ArmorOld.GetArmorsTiedTo(ID)
'            End If
'            Return m_Armors
'        End Get
'        Set(ByVal Value As List(Of ArmorOld))
'            m_Armors = Value
'        End Set
'    End Property

'    Public Property Weapons() As List(Of WeaponOld)
'        Get
'            If m_Weapons Is Nothing Then
'                m_Weapons = WeaponOld.GetWeaponsTiedTo(ID)
'            End If
'            Return m_Weapons
'        End Get
'        Set(ByVal Value As List(Of WeaponOld))
'            m_Weapons = Value
'        End Set
'    End Property

'    Public Property Type() As CharacterType
'        Get
'            Return m_Type
'        End Get
'        Set(ByVal Value As CharacterType)
'            m_Type = Value
'        End Set
'    End Property

'    Public Property StrengthBonus() As Integer
'        Get
'            Return m_StrengthBonus
'        End Get
'        Set(ByVal Value As Integer)
'            m_StrengthBonus = Value
'        End Set
'    End Property


'    '
'    Public Overrides Function ToString() As String
'        Return Name
'    End Function
'    Public Function GetActor(ByVal MD As MasterData) As Actor
'        Dim MyChar As New Actor

'        Dim Arm As ArmorOld
'        For Each Arm In Me.Armors
'            MyChar.ArmorList.Add(Arm)
'        Next
'        If MyChar.ArmorList.Count > 0 Then
'            MyChar.CurrentArmor = MyChar.ArmorList(0)
'        End If

'        MyChar.Level = Level
'        MyChar.BaseInititive = BaseInititive
'        If Type = CharacterType.PC Then
'            MyChar.RolledInititive = Val(InputBox("Roll Inititive for " & Name))
'        Else
'            Dim Roll As Integer = RMSS.RollOnes()
'            If Roll = 0 Then Roll = 10
'            MyChar.RolledInititive = Roll
'            Roll = RMSS.RollOnes()
'            If Roll = 0 Then Roll = 10
'            MyChar.RolledInititive += Roll
'        End If
'        MyChar.HitsTotal = HitPoints
'        MyChar.HitsRemaining = MyChar.HitsTotal
'        MyChar.ExhaustionTotal = ExhaustionPoints
'        MyChar.ExhaustionRemaining = MyChar.ExhaustionTotal
'        MyChar.PowerPointsTotal = PowerPoints
'        MyChar.PowerPointsRemaining = MyChar.PowerPointsTotal
'        MyChar.Type = Type
'        MyChar.StrengthBonus = Me.StrengthBonus
'        MyChar.PercentRequiredAdrenalDB = PercentRequiredAdrenalDB

'        Dim Wpn As WeaponOld
'        For Each Wpn In Me.Weapons
'            Dim atk As New AttackOld
'            atk.WeaponUsed = Wpn
'            atk.OB = Wpn.OB
'            atk.Type = AttackType.Weapon
'            MyChar.Attacks.Add(atk)
'        Next
'        'If MyChar.Attacks.Count > 0 Then MyChar.CurrentAttack = MyChar.Attacks(0)

'        Dim Ac As New StandardAction
'        Ac.Name = "Wait"
'        Ac.WhoIsActing = MyChar
'        MyChar.SetActionTime(Ac, MD)
'        MD.Actions.Add(Ac)
'        MyChar.CurrentAction(MD) = Ac
'        Return MyChar
'    End Function

'    Public Sub New()

'    End Sub
'    Public Sub New(ByVal info As System.Runtime.Serialization.SerializationInfo, ByVal context As System.Runtime.Serialization.StreamingContext)
'        Name = info.GetString("Name")
'        Level = info.GetInt32("Level")
'        BaseInititive = info.GetInt32("BaseInititive")
'        HitPoints = info.GetInt32("HitPoints")
'        ExhaustionPoints = info.GetInt32("ExhaustionPoints")
'        PowerPoints = info.GetInt32("PowerPoints")
'        Type = info.GetInt32("Type")
'        StrengthBonus = info.GetInt32("StrengthBonus")
'        Armors = info.GetValue("Armors", GetType(List(Of ArmorOld)))
'        Weapons = info.GetValue("Weapons", GetType(List(Of WeaponOld)))
'    End Sub
'    Public Sub Delete()
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "Delete From Characters where ID=@ID"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'        Cmd.ExecuteNonQuery()
'        ID = 0
'        If Flagg Then DB.ConnEnd()
'    End Sub
'    Public Sub Save()
'        Dim DBEn As New DBEnabled
'        Dim Flagg As Boolean = DBEn.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        If ID = 0 Then
'            SQL = "Insert into Characters (Name, Level, BaseInititive, HitPoints, ExhaustionPoints, PowerPoints, Type, StrengthBonus,PercentRequiredAdrenalDB) values (@Name, @Level, @BaseInititive, @HitPoints, @ExhaustionPoints, @PowerPoints, @Type, @StrengthBonus,@PercentRequiredAdrenalDB); Select @@Identity"
'        Else
'            SQL = "Update Characters Set Name=@Name, Level=@Level, BaseInititive=@BaseInititive, HitPoints=@HitPoints, ExhaustionPoints=@ExhaustionPoints, PowerPoints=@PowerPoints, Type=@Type, StrengthBonus=@StrengthBonus,PercentRequiredAdrenalDB=@PercentRequiredAdrenalDB Where ID=@ID"
'        End If
'        Cmd = New SqlClient.SqlCommand(SQL, DBEn.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Name", Name))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Level", Level))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@BaseInititive", BaseInititive))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@HitPoints", HitPoints))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@ExhaustionPoints", ExhaustionPoints))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@PowerPoints", PowerPoints))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Type", Type.ToString))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@StrengthBonus", StrengthBonus))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@PercentRequiredAdrenalDB", PercentRequiredAdrenalDB))
'        If ID = 0 Then
'            ID = Cmd.ExecuteScalar
'        Else
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'            Cmd.ExecuteNonQuery()
'        End If
'        If m_Weapons IsNot Nothing Then
'            Dim Weap As WeaponOld
'            For Each Weap In Weapons
'                Weap.Save(Me.ID)
'            Next
'        End If
'        If m_Armors IsNot Nothing Then
'            Dim Arm As ArmorOld
'            For Each Arm In Armors
'                Arm.Save(Me.ID)
'            Next
'        End If

'        If Flagg Then DBEn.ConnEnd()
'    End Sub

'    Private Sub Load(ByVal DR As DataRow)
'        'Name, Level, BaseInititive, HitPoints, ExhaustionPoints, PowerPoints, Type, StrengthBonus
'        ID = CInt(GetData(DR, "ID"))
'        Name = GetData(DR, "Name")
'        Level = CInt(GetData(DR, "Level"))
'        BaseInititive = CInt(GetData(DR, "BaseInititive"))
'        HitPoints = CInt(GetData(DR, "HitPoints"))
'        ExhaustionPoints = CInt(GetData(DR, "ExhaustionPoints"))
'        PowerPoints = CInt(GetData(DR, "PowerPoints"))
'        StrengthBonus = CInt(GetData(DR, "StrengthBonus"))
'        Type = [Enum].Parse(GetType(CharacterType), GetData(DR, "Type"))
'        PercentRequiredAdrenalDB = CDbl(GetData(DR, "PercentRequiredAdrenalDB"))
'    End Sub
'    Public Shared Function Load(ByVal ID As Integer) As PreBuiltCharOld
'        Dim DB As New DBEnabled
'        Dim CI As New PreBuiltCharOld
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,Name, Level, BaseInititive, HitPoints, ExhaustionPoints, PowerPoints, Type, StrengthBonus,PercentRequiredAdrenalDB FROM Characters where ID=@ID"

'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        If DT.Rows.Count > 0 Then
'            DR = DT.Rows(0)
'            CI.Load(DR)
'        End If
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return CI
'    End Function
'    Public Shared Function Find(ByVal Type As String) As PreBuiltCharOld
'        Dim DB As New DBEnabled
'        Dim CI As New PreBuiltCharOld
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,Name, Level, BaseInititive, HitPoints, ExhaustionPoints, PowerPoints, Type, StrengthBonus,PercentRequiredAdrenalDB FROM Characters where Type=@Type"

'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Type", Type))
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        If DT.Rows.Count > 0 Then
'            DR = DT.Rows(0)
'            CI.Load(DR)
'        End If
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return CI
'    End Function
'    Public Shared Function GetPreBuiltChars() As Generic.List(Of PreBuiltCharOld)
'        Dim List As New Generic.List(Of PreBuiltCharOld)
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,Name, Level, BaseInititive, HitPoints, ExhaustionPoints, PowerPoints, Type, StrengthBonus,PercentRequiredAdrenalDB FROM Characters"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        For Each DR In DT.Rows
'            Dim CI As New PreBuiltCharOld
'            CI.Load(DR)
'            List.Add(CI)
'        Next
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return List
'    End Function

'    Public Sub GetObjectData(ByVal info As System.Runtime.Serialization.SerializationInfo, ByVal context As System.Runtime.Serialization.StreamingContext) Implements System.Runtime.Serialization.ISerializable.GetObjectData

'    End Sub
'End Class
