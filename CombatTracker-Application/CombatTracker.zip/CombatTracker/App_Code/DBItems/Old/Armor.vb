
'<Serializable()> Public Class ArmorOld
'    Implements System.Runtime.Serialization.ISerializable

'    Private m_ID As Integer
'    Private m_Type As Integer
'    Private m_Description As String
'    Private m_MovingManeuverMod As Integer
'    Private m_DB As Integer
'    Private m_BaseArmor As ArmorOld
'    Private BaseArmor_ID As Integer
'    Public Property BaseArmor() As ArmorOld
'        Get
'            If m_BaseArmor Is Nothing Then
'                m_BaseArmor = ArmorOld.Load(BaseArmor_ID)
'            End If
'            Return m_BaseArmor
'        End Get
'        Set(ByVal Value As ArmorOld)
'            m_BaseArmor = Value
'        End Set
'    End Property



'    Public Sub New()

'    End Sub
'    Public Sub New(ByVal info As System.Runtime.Serialization.SerializationInfo, ByVal context As System.Runtime.Serialization.StreamingContext)
'        Description = info.GetString("Description")
'        Type = info.GetInt32("Type")
'        MovingManeuverMod = info.GetInt32("MovingManeuverMod")
'        DB = info.GetInt32("DB")

'        BaseArmor = info.GetValue("BaseArmor", GetType(ArmorOld))

'    End Sub
'    Public Property ID() As Integer
'        Get
'            Return m_ID
'        End Get
'        Set(ByVal Value As Integer)
'            m_ID = Value
'        End Set
'    End Property

'    Public Property Type() As Integer
'        Get
'            Return m_Type
'        End Get
'        Set(ByVal Value As Integer)
'            m_Type = Value
'        End Set
'    End Property

'    Public Property Description() As String
'        Get
'            Return m_Description
'        End Get
'        Set(ByVal Value As String)
'            m_Description = Value
'        End Set
'    End Property

'    Public Property MovingManeuverMod() As Integer
'        Get
'            Return m_MovingManeuverMod
'        End Get
'        Set(ByVal Value As Integer)
'            m_MovingManeuverMod = Value
'        End Set
'    End Property

'    Public Property DB() As Integer
'        Get
'            Return m_DB
'        End Get
'        Set(ByVal Value As Integer)
'            m_DB = Value
'        End Set
'    End Property

'    Public Function Clone() As ArmorOld
'        Dim ar As New ArmorOld
'        ar.Type = Type
'        ar.Description = Description
'        ar.MovingManeuverMod = Me.MovingManeuverMod
'        ar.BaseArmor = Me
'        ar.DB = DB
'        Return ar
'    End Function
'    Public Overrides Function ToString() As String
'        Return Type
'    End Function


'    Public Sub GetObjectData(ByVal info As System.Runtime.Serialization.SerializationInfo, ByVal context As System.Runtime.Serialization.StreamingContext) Implements System.Runtime.Serialization.ISerializable.GetObjectData

'    End Sub


'    Public Sub Delete()
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "Delete From Armors where ID=@ID"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'        Cmd.ExecuteNonQuery()
'        ID = 0
'        If Flagg Then DB.ConnEnd()
'    End Sub
'    Public Sub Save(Optional ByVal TiedToID As Integer = 0)
'        Dim DBEn As New DBEnabled
'        Dim Flagg As Boolean = DBEn.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        If ID = 0 Then
'            SQL = "Insert into Armors (Type,Description,MovingManeuverMod,DB,BaseArmor_ID,TiedToID) values (@Type,@Description,@MovingManeuverMod,@DB,@BaseArmor_ID,@TiedToID); Select @@Identity"
'        Else
'            SQL = "Update Armors Set Type=@Type,Description=@Description,MovingManeuverMod=@MovingManeuverMod,DB=@DB,BaseArmor_ID=@BaseArmor_ID,TiedToID=@TiedToID Where ID=@ID"
'        End If
'        Cmd = New SqlClient.SqlCommand(SQL, DBEn.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Type", Type))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Description", Description))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@MovingManeuverMod", MovingManeuverMod))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@DB", DB))
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@TiedToID", TiedToID))
'        If m_BaseArmor Is Nothing Then
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@BaseArmor_ID", BaseArmor_ID))
'        Else
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@BaseArmor_ID", BaseArmor.ID))
'        End If
'        If ID = 0 Then
'            ID = Cmd.ExecuteScalar
'        Else
'            Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'            Cmd.ExecuteNonQuery()
'        End If
'        If Flagg Then DBEn.ConnEnd()
'    End Sub

'    Private Sub Load(ByVal DR As DataRow)
'        'Type,Description,MovingManeuverMod,DB,BaseArmor_ID
'        ID = CInt(GetData(DR, "ID"))
'        Type = CInt(GetData(DR, "Type"))
'        Description = GetData(DR, "Description")
'        MovingManeuverMod = CInt(GetData(DR, "MovingManeuverMod"))
'        DB = CInt(GetData(DR, "DB"))
'        BaseArmor_ID = CInt(GetData(DR, "BaseArmor_ID"))
'    End Sub
'    Public Shared Function Load(ByVal ID As Integer) As ArmorOld
'        Dim DB As New DBEnabled
'        Dim CI As New ArmorOld
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,Type,Description,MovingManeuverMod,DB,BaseArmor_ID FROM Armors where ID=@ID"

'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@ID", ID))
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        If DT.Rows.Count > 0 Then
'            DR = DT.Rows(0)
'            CI.Load(DR)
'        End If
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return CI
'    End Function
'    Public Shared Function Find(ByVal Type As String) As ArmorOld
'        Dim DB As New DBEnabled
'        Dim CI As New ArmorOld
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,Type,Description,MovingManeuverMod,DB,BaseArmor_ID FROM Armors where Type=@Type"

'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@Type", Type))
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        If DT.Rows.Count > 0 Then
'            DR = DT.Rows(0)
'            CI.Load(DR)
'        End If
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return CI
'    End Function
'    Public Shared Function GetArmors() As Generic.List(Of ArmorOld)
'        Dim List As New Generic.List(Of ArmorOld)
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,Type,Description,MovingManeuverMod,DB,BaseArmor_ID FROM Armors"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        For Each DR In DT.Rows
'            Dim CI As New ArmorOld
'            CI.Load(DR)
'            List.Add(CI)
'        Next
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return List
'    End Function
'    Public Shared Function GetArmorsTiedTo(ByVal TiedToID As Integer) As Generic.List(Of ArmorOld)
'        Dim List As New Generic.List(Of ArmorOld)
'        Dim DB As New DBEnabled
'        Dim Flagg As Boolean = DB.ConnStart()
'        Dim SQL As String
'        Dim Cmd As SqlClient.SqlCommand
'        SQL = "SELECT ID,Type,Description,MovingManeuverMod,DB,BaseArmor_ID FROM Armors where TiedToID=@TiedToID"
'        Cmd = New SqlClient.SqlCommand(SQL, DB.MyConn)
'        Cmd.Parameters.Add(New SqlClient.SqlParameter("@TiedToID", TiedToID))
'        Dim DA As New SqlClient.SqlDataAdapter(Cmd)
'        Dim DT As New DataTable
'        DA.Fill(DT)
'        DA.Dispose()
'        Cmd.Dispose()
'        Dim DR As DataRow
'        For Each DR In DT.Rows
'            Dim CI As New ArmorOld
'            CI.Load(DR)
'            List.Add(CI)
'        Next
'        DT.Dispose()
'        If Flagg Then DB.ConnEnd()
'        Return List
'    End Function

'End Class
