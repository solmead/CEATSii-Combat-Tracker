﻿Partial Class CriticalCode
    Inherits IEntity(Of CriticalCode)
    Public Overrides Function ToString() As String
        Return Name
    End Function

End Class
