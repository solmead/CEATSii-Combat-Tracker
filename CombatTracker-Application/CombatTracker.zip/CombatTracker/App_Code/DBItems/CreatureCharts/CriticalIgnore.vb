﻿Partial Class CriticalIgnore
    Inherits IEntity(Of CriticalIgnore)

    Public Overrides Function ToString() As String
        Return Name
    End Function
End Class
