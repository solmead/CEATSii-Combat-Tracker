
<Serializable()> Public Class Actor
    Public BaseCreature As Creature
    Public Name As String
    Public Type As CharacterType
    Public Level As Integer
    'Public DB As Integer
    Public HitsTotal As Integer
    Public HitsRemaining As Integer
    Public BaseInititive As Integer
    Public RolledInititive As Integer
    Public ExhaustionTotal As Integer
    Public ExhaustionRemaining As Integer
    Public PowerPointsTotal As Integer
    Public PowerPointsRemaining As Integer
    Public IsConcentrating As Boolean
    Public Suprised As Boolean
    Public UsingAdrenalDB As Boolean
    Public PercentRequiredAdrenalDB As Double = 0.4
    'Public UnderHaste As Boolean
    Public PercentAction As Integer = 100
    Public StrengthBonus As Integer
    'Public CurModifier As Double
    Public CritNegatives As Integer
    Private CurAction As Action
    Public ActionsHistory As New List(Of Action)
    Public CritHistory As New List(Of CritAffects)
    Public Wounds As New ArrayList

    Public Attacks As New List(Of Attack)
    Public WeaponList As New List(Of Attack)
    'Public CurrentAttack As Attack
    Public CurrentArmor As Armor
    Public ArmorList As New List(Of Armor)
    Public NextSpellTime As Double
    Public ConStat As Integer = 90
    'Public ActionCount As Integer = 0
    Private CritRounds As New List(Of CritAffects)
    Public Movement As Double
    Public Sub HandleDeath(ByVal GI As GameInstance)
        If Not (TypeOf (CurrentAction) Is DeathAction) Then
            Dim Nact As Action = New DeathAction(Me, GI.CurrentTime)
            Nact.WhoIsActing = Me
            GI.Actions.Add(Nact)
            Me.CurrentAction(GI) = Nact
            GI.Actions = From a In GI.Actions Order By a.EndTime Select a
        End If
    End Sub
    Public Sub HandleInitChange(ByVal CurrentTime As Double)
        Dim CurAct As Action = Me.CurrentAction
        Dim PerRemain As Double = 0
        PerRemain = 1 - CurAct.PercentageCompleted(CurrentTime)
        CurAct.EndTime = CurrentTime + PerRemain * Me.CalculateTimeRequired(CurAct.BasePercent * BaseRoundTime, CurAct.CurrentModifier, CurAct.Type = ActionType.Attack, CurAct.CurrentAttack)
    End Sub
    Public Function StunRounds() As Integer
        Dim Cnt As Integer = 0
        Dim CR As CritAffects
        For Each CR In CritRounds
            If CR.IsStunned Then Cnt += 1
        Next
        Return Cnt
    End Function
    Public Function ParryRounds() As Integer
        Dim Cnt As Integer = 0
        Dim CR As CritAffects
        For Each CR In CritRounds
            If CR.Parry <> CritAffects.ParryType.Fine Then Cnt += 1
        Next
        Return Cnt
    End Function
    Public Function NegativeRounds() As Integer
        Dim Cnt As Integer = 0
        Dim CR As CritAffects
        For Each CR In CritRounds
            If CR.Negative <> 0 Then Cnt += 1
        Next
        Return Cnt
    End Function

    Public ReadOnly Property CurrentCrits() As CritAffects
        Get
            If CritRounds.Count > 0 Then
                Return CritRounds(0)
            Else
                Return Nothing
            End If
        End Get
    End Property
    Public Sub RemoveCrit(ByVal CurrentTime As Double)
        If CritRounds.Count = 0 Then Exit Sub
        CritRounds.RemoveAt(0)
        Dim ca As CritAffects
        If CritRounds.Count = 0 Then Exit Sub
        ca = CritRounds(0)
        If ca.TimeStart = 0 Then
            ca.TimeStart = CurrentTime
            ca.TimeEnd = Me.CalculateTimeRequiredNonEnc(BaseRoundTime) + CurrentTime
        End If
        CritHistory.Add(ca)
    End Sub
    Public Sub AddRoundsCritAffects(ByVal CAffect As CritAffects, ByVal Rounds As Integer, ByVal CurrentTime As Double)
        Dim ca As CritAffects
        Dim RS As Integer
        Dim RNP As Integer
        Dim RMP As Integer
        Dim RNeg As Integer
        Dim flag As Boolean = CritRounds.Count = 0
        If CAffect.Parry = CritAffects.ParryType.No_Parry Then RNP = Rounds
        If CAffect.Parry = CritAffects.ParryType.Must_Parry Then RMP = Rounds
        If CAffect.IsStunned Then RS = Rounds
        If CAffect.Negative <> 0 Then RNeg = Rounds
        For Each ca In CritRounds
            If ca.TimeStart = 0 OrElse ca.TimeStart = CurrentTime OrElse (ca.TimeEnd - ca.TimeStart) * 0.5 >= (CurrentTime - ca.TimeStart) Then
                If Not ca.IsStunned AndAlso RS > 0 Then
                    ca.IsStunned = True
                    RS -= 1
                End If
                If ca.Parry = CritAffects.ParryType.Fine AndAlso RMP > 0 Then
                    ca.Parry = CritAffects.ParryType.Must_Parry
                    ca.ParryNegative = CAffect.ParryNegative
                    RMP -= 1
                ElseIf ca.Parry = CritAffects.ParryType.No_Parry AndAlso RMP > 0 Then
                    RMP -= 1
                End If
                If ca.Parry <> CritAffects.ParryType.No_Parry AndAlso RNP > 0 Then
                    ca.Parry = CritAffects.ParryType.No_Parry
                    ca.ParryNegative = 0
                    RNP -= 1
                End If
                If RNeg > 0 Then
                    ca.Negative += CAffect.Negative
                    RNeg -= 1
                End If
            End If
        Next
        While RS > 0 OrElse RMP > 0 OrElse RNP > 0 OrElse RNeg > 0
            ca = New CritAffects
            If RS > 0 Then
                ca.IsStunned = True
                RS -= 1
            End If
            If RMP > 0 Then
                ca.Parry = CritAffects.ParryType.Must_Parry
                ca.ParryNegative = CAffect.ParryNegative
                RMP -= 1
            End If
            If RNP > 0 Then
                ca.Parry = CritAffects.ParryType.No_Parry
                ca.ParryNegative = 0
                RNP -= 1
            End If
            If RNeg > 0 Then
                ca.Negative += CAffect.Negative
                RNeg -= 1
            End If
            CritRounds.Add(ca)
        End While
        ca = CritRounds(0)
        If ca.TimeStart = 0 Then
            ca.TimeStart = CurrentTime
            ca.TimeEnd = Me.CalculateTimeRequiredNonEnc(BaseRoundTime) + CurrentTime
        End If
        If flag Then
            CritHistory.Add(ca)
        End If
    End Sub

    Private Function HitNegatives() As Integer
        If HitsRemaining >= 0.75 * HitsTotal Then
            Return 0
        ElseIf HitsRemaining >= 0.5 * HitsTotal Then
            Return -10
        ElseIf HitsRemaining >= 0.25 * HitsTotal Then
            Return -20
        Else
            Return -30
        End If
    End Function
    Private Function ExhNegatives()
        If ExhaustionRemaining >= 0.75 * ExhaustionTotal Then
            Return 0
        ElseIf ExhaustionRemaining >= 0.5 * ExhaustionTotal Then
            Return -5
        ElseIf ExhaustionRemaining >= 0.25 * ExhaustionTotal Then
            Return -15
        ElseIf ExhaustionRemaining >= 0.1 * ExhaustionTotal Then
            Return -30
        ElseIf ExhaustionRemaining >= 0.01 * ExhaustionTotal Then
            Return -60
        Else
            Return -100
        End If
    End Function
    Public ReadOnly Property Negatives() As Integer
        Get
            Dim T As Integer = 0
            If CurrentCrits IsNot Nothing Then T = CurrentCrits.Negative
            Return CritNegatives + HitNegatives() + ExhNegatives() + T
        End Get
    End Property
    Public Function SpellNegatives() As Integer
        If PowerPointsRemaining >= 0.75 * PowerPointsTotal Then
            Return 0 + Negatives
        ElseIf PowerPointsRemaining >= 0.5 * PowerPointsTotal Then
            Return -10 + Negatives
        ElseIf PowerPointsRemaining >= 0.25 * PowerPointsTotal Then
            Return -20 + Negatives
        Else
            Return -30 + Negatives
        End If
    End Function
    Public ReadOnly Property CurrentAction() As Action
        Get
            Return CurAction
        End Get
    End Property
    Public WriteOnly Property CurrentAction(ByVal MD As GameInstance) As Action
        Set(ByVal value As Action)
            If CurAction IsNot Nothing AndAlso CurAction.EndTime >= MD.CurrentTime Then
                CurAction.Interrupted = True
                CurAction.EndTime = MD.CurrentTime
                MD.Actions.Remove(CurAction)
            Else
                'Debug.WriteLine("Time not elapsed")
            End If
            CurAction = value
            If CurAction.EndTime = 0 Then CurAction.EndTime = MD.CurrentTime + Me.CalculateTimeRequired(CurAction.BasePercent * BaseRoundTime, CurAction.CurrentModifier, CurAction.Type = ActionType.Attack, CurAction.CurrentAttack)
            ActionsHistory.Add(CurAction)
        End Set
    End Property
    Public Sub SetActionTime(ByVal Act As Action, ByVal CurrentTime As Double)
        Act.StartTime = CurrentTime
        Act.EndTime = CurrentTime + Me.CalculateTimeRequired(Act.BasePercent * BaseRoundTime, Act.CurrentModifier, Act.Type = ActionType.Attack, Act.CurrentAttack)
    End Sub
    Public ReadOnly Property Inititive()
        Get
            Return BaseInititive + RolledInititive - 11
        End Get
    End Property



    Public Overrides Function ToString() As String
        Return Name
    End Function

    Public Function CalculateTimeRequired(ByVal BaseTime As Double, ByVal Modifier As Integer, ByVal IsAttack As Boolean, ByVal CurrentAttack As Attack) As Double
        Dim Init As Double
        Init = Me.Inititive
        If Me.HitsRemaining < Me.HitsTotal / 2 Then
            Init -= 8
        End If
        If Me.IsConcentrating Then
            Init -= 30
        End If
        If Me.Suprised Then
            Init -= 30
        End If
        Init += 3 * Me.CurrentArmor.MovingManeuverMod / 10
        If IsAttack AndAlso CurrentAttack IsNot Nothing AndAlso CurrentAttack.WeaponUsed IsNot Nothing Then
            Init += 3 * Me.Attacks(0).WeaponUsed.Bonus / 5
            If Not Me.Attacks(0).WeaponUsed.Is2Handed Then
                Init += Me.StrengthBonus - Me.Attacks(0).WeaponUsed.Weight
            Else
                Init += Me.StrengthBonus - Me.Attacks(0).WeaponUsed.Weight / 2
            End If
        End If
        'Init += 8 * -Modifier / 10
        'Dim BInit As Double = Init
        If Me.UsingAdrenalDB Then
            Init += (100 + Init) * (1 / ((100 + (Me.PercentRequiredAdrenalDB * 100)) / 100) - 1) '(1 + Me.PercentRequiredAdrenalDB / 100) - 1) + Init
        End If
        Init += (100 + Init) * (1 / ((100 + Modifier) / 100) - 1)
        BaseTime = BaseTime / (Me.PercentAction / 100)
        'If Me.UnderHaste Then
        'BaseTime = BaseTime / 2
        'End If
        Debug.WriteLine(Init)
        Return BaseTime * (100 / (100 + (Init)))
    End Function
    Public Function CalculateTimeRequiredNonEnc(ByVal BaseTime As Double) As Double
        Dim Init As Double
        Init = Me.Inititive
        If Me.HitsRemaining < Me.HitsTotal / 2 Then
            Init -= 8
        End If
        Dim BInit As Double = Init
        If Me.UsingAdrenalDB Then
            Init = (100 + BInit) * (1 / (1 + Me.PercentRequiredAdrenalDB / 100) - 1) + Init
        End If
        BaseTime = BaseTime / (Me.PercentAction / 100)
        'If Me.UnderHaste Then
        '    BaseTime = BaseTime / 2
        'End If
        Return BaseTime * (100 / (100 + (Init)))
    End Function
    Public Function CalculateTimeRequiredForSpells(ByVal BaseTime As Double) As Double
        Dim Init As Double
        Init = Me.Inititive
        Return BaseTime * (100 / (100 + (Init)))
    End Function
End Class

