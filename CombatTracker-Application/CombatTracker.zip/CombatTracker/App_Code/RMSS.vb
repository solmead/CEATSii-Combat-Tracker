'Public Class RMSSData

'    'Private XMl As New Xml.XmlDocument

'    Public ActionGroups As New List(Of ActionGroup)


'    Public ConBonusChart As ConstitutionBonusChart
'    Public LevelChart As LevelChart
'    Public SpeedChart As SpeedChart
'    Public RefractoryPeriodModChart As PsychicRefactoryPeriodChart

'    Public Sub New()
'        Try
'            'XMl = New Xml.XmlDocument
'            'XMl.Load(My.Application.Info.DirectoryPath & "\datafile.xml")
'            ConBonusChart = ConstitutionBonusChart.Load()
'            'ConBonusChart.save()
'            LevelChart = LevelChart.Load()
'            'LevelChart.Save()
'            SpeedChart = SpeedChart.Load()
'            'SpeedChart.save()
'            RefractoryPeriodModChart = PsychicRefactoryPeriodChart.Load()
'            'RefractoryPeriodModChart.save()
'            ActionGroups = ActionGroup.GetActionGroups()
'            'Dim aG As ActionGroup
'            'For Each aG In ActionGroups
'            'aG.Save()
'            'Next
'        Catch ex As Exception
'            Debug.WriteLine(ex.ToString)
'        End Try
'    End Sub

'End Class
